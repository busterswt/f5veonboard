#!/bin/bash
source odk-utils
source f5-onboard-utils


function show_usage {
    echo "Usage:"
    echo "f5-onboard-ve-odk upgrade-tenant-bigips"
    echo "  --tenant_index     Which tenant"
}

# Parse command line switches
while [ $# -gt 0 ]; do
    case "$1" in
        --odk-tenant-index)  ODK_TENANT_INDEX=$2 ; shift 2 ;;
        help|--help)    show_usage; exit 0;;
        *)              show_usage; exit 1;;
    esac
done

if [ -z "$ODK_TENANT_INDEX" ]; then
    show_usage
    exit 1
fi

CLUSTER_NAME=proj_${ODK_TENANT_INDEX}-1
BIGIP_IMAGE=`f5-onboard-get-state clusters $CLUSTER_NAME BIGIP_IMAGE`
HA_TYPE=`f5-onboard-get-state clusters $CLUSTER_NAME HA_TYPE`
NUM_BIGIPS=`f5-onboard-get-state clusters $CLUSTER_NAME NUM_BIGIPS`

# we run this even for standalone mode because
# this configures the hostname and turns off strict 
# route domains
set -e # exit on error
set -x # echo commands
stdbuf -o 0 -e 0 \
  python $F5_ONBOARD_BIGIP_PY_DIR/cluster_ve_os_tenant.py \
                       --os-tenant-name proj_${ODK_TENANT_INDEX} \
                       --os-username user_$ODK_TENANT_INDEX \
                       --os-password user_$ODK_TENANT_INDEX \
                       --ha-type $HA_TYPE \
                       --num-bigips $NUM_BIGIPS

set +x
set +e
if [ "$HA_TYPE" != "standalone" ]; then
    echo "Sleeping 60 seconds until BIG-IPs are clustered"
    sleep 60
fi


