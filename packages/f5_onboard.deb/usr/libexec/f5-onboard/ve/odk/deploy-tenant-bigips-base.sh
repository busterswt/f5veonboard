#!/bin/bash
source odk-utils
source f5-onboard-utils

BIGIP_IMAGE="BIGIP-11.5.0.0.0.221-OpenStack.qcow2"
HA_TYPE=pair

function show_usage {
    echo "Usage:" 
    echo "f5-onboard-ve-odk deploy-tenant-bigips-base"
    echo "  --odk-tenant-index     Which tenant"; \
    echo "  --ha-type          Which High Availability type to use: standalone, pair, scalen"; \
    echo "                     Default: pair"; \
    echo "  --bigip-image      Which BIG-IP to use"; \
    echo "                     Default: BIGIP-11.5.0.0.0.221-OpenStack.qcow2"; \
}

# Parse command line switches
while [ $# -gt 0 ]; do
   case "$1" in
       --odk-tenant-index) ODK_TENANT_INDEX=$2 ; shift 2 ;;
       --ha-type)      HA_TYPE=$2 ; shift 2 ;;
       --bigip-image)  BIGIP_IMAGE=$2 ; shift 2 ;;
       help|--help)    show_usage; exit 0;;
       *)              show_usage; exit 1;;
   esac
done


# Gather necessary configuration using address helpers
OPT_NO_CLEAN=--verbose\ --check\ --no-cleanup

set -e # exit on error
set -x # echo commands

odk-network $OPT_NO_CLEAN \
            --odk-tenant-index $ODK_TENANT_INDEX \
            --network-index 10 \
            --network-name bigip_mgmt

if [ "$HA_TYPE" != "standalone" ]; then
    # ha network
    odk-network $OPT_NO_CLEAN \
                --odk-tenant-index $ODK_TENANT_INDEX \
                --network-index 11 \
                --network-name bigip_ha

    # mirroring network
    odk-network $OPT_NO_CLEAN \
                --odk-tenant-index $ODK_TENANT_INDEX \
                --network-index 12 \
                --network-name bigip_mirror
fi

# Should we create under tenant project?
# Just use admin's (already created) image for now.
#odk-admin-image $OPT_NO_CLEAN \
#                --image $F5_ONBOARD_IMAGE_DIR/$BIGIP_IMAGE
set +x

