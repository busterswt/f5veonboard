#!/bin/bash
source odk-utils
source f5-onboard-utils

BIGIP_IMAGE=`f5-onboard-get-state clusters admin1 BIGIP_IMAGE`
HA_TYPE=`f5-onboard-get-state clusters admin1 HA_TYPE`
NUM_BIGIPS=`f5-onboard-get-state clusters admin1 NUM_BIGIPS`

# we run this even for standalone mode because
# this configures the hostname and turns off strict 
# route domains
set -e # exit on error
set -x # echo commands
stdbuf -o 0 -e 0 \
  python $F5_ONBOARD_BIGIP_PY_DIR/cluster_ve_os.py \
                       --ha-type $HA_TYPE \
                       --num-bigips $NUM_BIGIPS
set +x
set +e
if [ "$HA_TYPE" != "standalone" ]; then
    echo "Sleeping 60 seconds until BIG-IPs are clustered"
    sleep 60
fi


