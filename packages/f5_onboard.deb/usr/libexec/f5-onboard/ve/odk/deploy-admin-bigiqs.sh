#!/bin/bash
source odk-utils
source f5-onboard-utils

function show_usage {
    echo "Usage:"
    echo "f5-onboard-ve-odk deploy-bigiqs"
    echo "  --bigiq-image      Which BIG-IQ image to use"; \
    echo "                     Default: BIG-IQ-4.5.0.0.0.7028-OpenStack.qcow2"; \
    echo "  --ha-type          Which High Availability type to use: standalone, pair, scalen"; \
    echo "                     Default: standalone"; \
    echo "  --num-bigiqs       Number of big-iqs to deploy for scalen mode"; \
    echo "                     Default: 4"; \
}


BIGIQ_IMAGE="BIG-IQ-4.5.0.0.0.7028-OpenStack.qcow2"
HA_TYPE=standalone

# Parse command line switches
while [ $# -gt 0 ]; do
   case "$1" in
       --bigiq-image)  BIGIQ_IMAGE=$2 ; shift 2 ;;
       --ha-type)      HA_TYPE=$2 ; shift 2 ;;
       --num-bigiqs)   NUM_BIGIQS=$2 ; shift 2 ;;
       -h|help|--help) show_usage; exit 0;;
       *)              show_usage; exit 1;;
   esac
done

# convert ha type to number of big-ips
if [ "$HA_TYPE" == "standalone" ]; then
    NUM_BIGIQS=1
elif [ "$HA_TYPE" == "pair" ]; then
    NUM_BIGIQS=2
elif [ "$HA_TYPE" == "scalen" ]; then
    if [ -z "$NUM_BIGIQS" ]; then
        NUM_BIGIQS=$BIGIQ_SCALEN_DEFAULT_SIZE
    fi
else
    echo "Invalid HA type!"
    show_usage
    exit 1
fi

BIGIQ_AVAILABLE_REG_KEYS="startup.licenses.bigiq"
BIGIQ_USED_REG_KEYS="startup.licenses.bigiq.used"
BIGIQ_REMAINING_REG_KEYS="startup.licenses.bigiq.left"

# Helper function for licensing
function prepare_metadata_for_bigiq {
    bigiq_idx=$1

    # get license from file and then remove it
    license=`head -1 $F5_ONBOARD_CONF_DIR/$BIGIQ_AVAILABLE_REG_KEYS`
    echo "Using license $license"
    tail -n +2 $F5_ONBOARD_CONF_DIR/$BIGIQ_AVAILABLE_REG_KEYS \
         > $F5_ONBOARD_CONF_DIR/$BIGIQ_REMAINING_REG_KEYS
    mv $F5_ONBOARD_CONF_DIR/$BIGIQ_REMAINING_REG_KEYS \
         $F5_ONBOARD_CONF_DIR/$BIGIQ_AVAILABLE_REG_KEYS

    # Populate metadata with license
    mkdir -p $F5_ONBOARD_TMP_DIR
    cat $F5_ONBOARD_LIB_DIR/config-templates/startup_metadata.json-template \
          | sed "s/\$key/$license/" \
          > $F5_ONBOARD_TMP_DIR/startup_metadata_bigiq_$bigiq_idx.json

    echo $license >> $F5_ONBOARD_CONF_DIR/$BIGIQ_USED_REG_KEYS
}


# Move used reg keys from prior run to available reg keys
if [ -f $F5_ONBOARD_CONF_DIR/$BIGIQ_USED_REG_KEYS ]; then
    cat $F5_ONBOARD_CONF_DIR/$BIGIQ_USED_REG_KEYS \
          >> $F5_ONBOARD_CONF_DIR/$BIGIQ_AVAILABLE_REG_KEYS
fi
> $F5_ONBOARD_CONF_DIR/$BIGIQ_USED_REG_KEYS


# Create each of the BIG-IQ instances
for (( bigiq_index=1; bigiq_index<=$NUM_BIGIQS; bigiq_index++ ))
do
    # this sets the license
    prepare_metadata_for_bigiq $bigiq_index
done

# The script writes the assigned floating-ips to the following file
# TODO: it should call f5-onboard-set-state
set -x
set -e # exit on error
odkcmd f5-onboard-ve-openstack deploy-admin-bigiqs \
                                 --ha-type $HA_TYPE \
                                 --bigiq-image $BIGIQ_IMAGE \
                                 --num-bigiqs $NUM_BIGIQS
set +e
BIGIQ_MGMT_IPS=`cat $F5_ONBOARD_TMP_DIR/bigiq-addrs`

f5-onboard-set-state deployments odk-maas CLUSTER_NAME=admin1
f5-onboard-set-state clusters admin1 ODK_DEPLOYMENT=odk-maas
f5-onboard-set-state clusters admin1 BIGIQ_IMAGE=$BIGIQ_IMAGE
f5-onboard-set-state clusters admin1 BIGIQ_HA_TYPE=$HA_TYPE
f5-onboard-set-state clusters admin1 NUM_BIGIQS=$NUM_BIGIQS
f5-onboard-set-state clusters admin1 BIGIQ_MGMT_IPS=$BIGIQ_MGMT_IPS

set -e # exit on error
odkcmd f5-onboard-ve-odk upgrade-admin-bigiqs

# we run this even for standalone mode because
# this configures the hostname and turns off strict 
# route domains
odkcmd f5-onboard-ve-odk cluster-admin-bigiqs

set +e

set +x

