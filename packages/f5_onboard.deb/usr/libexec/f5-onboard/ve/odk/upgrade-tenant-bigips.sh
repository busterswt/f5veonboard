#!/bin/bash
source odk-utils
source f5-onboard-utils

# Gather necessary configuration
$(odk_creds)

function show_usage {
    echo "Usage:"
    echo "f5-onboard-ve-odk upgrade-tenant-bigips"
    echo "  --tenant_index     Which tenant"
}

# Parse command line switches
while [ $# -gt 0 ]; do
    case "$1" in
        --odk-tenant-index)  ODK_TENANT_INDEX=$2 ; shift 2 ;;
        help|--help)    show_usage; exit 0;;
        *)              show_usage; exit 1;;
    esac
done

if [ -z "$ODK_TENANT_INDEX" ]; then
    show_usage
    exit 1
fi
BIGIP_IMAGE=`f5-onboard-get-state clusters proj_${ODK_TENANT_INDEX}-1 BIGIP_IMAGE`
NUM_BIGIPS=`f5-onboard-get-state clusters proj_${ODK_TENANT_INDEX}-1 NUM_BIGIPS`

# Determine if image has a hotfix patch.  If so, perform upgrade
IFS='-' read -a image_components <<< "$BIGIP_IMAGE"
if [ -n "${image_components[3]}" ]; then
    base_full=${image_components[1]}
    hotfix_build=${image_components[3]}
    IFS='.' read -a base_components <<< "$base_full"
    base_version="${base_components[0]}.${base_components[1]}.${base_components[2]}"
    base_build="${base_components[3]}.${base_components[4]}.${base_components[5]}"

    set -e # exit on error
    set -x # echo commands
    stdbuf -o 0 -e 0 \
      python $F5_ONBOARD_BIGIP_PY_DIR/upgrade_tenant.py \
          --os-tenant-name proj_${ODK_TENANT_INDEX} \
          --os-username user_$ODK_TENANT_INDEX \
          --os-password user_$ODK_TENANT_INDEX \
          --external-network-name proj_${ODK_TENANT_INDEX}_net_2_external \
          --internal-network-name proj_${ODK_TENANT_INDEX}_net_1_internal \
          --num-bigips $NUM_BIGIPS \
          --base-version $base_version \
          --base-build $base_build \
          --hotfix-build $hotfix_build
    set +x
    set +e
fi

