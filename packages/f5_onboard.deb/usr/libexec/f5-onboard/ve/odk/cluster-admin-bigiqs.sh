#!/bin/bash
source odk-utils
source f5-onboard-utils

BIGIQ_IMAGE=`f5-onboard-get-state clusters admin1 BIGIQ_IMAGE`
BIGIQ_HA_TYPE=`f5-onboard-get-state clusters admin1 BIGIQ_HA_TYPE`
NUM_BIGIQS=`f5-onboard-get-state clusters admin1 NUM_BIGIQS`

# we run this even for standalone mode because
# this configures the hostname
set -e # exit on error
set -x # echo commands
stdbuf -o 0 -e 0 \
  python $F5_ONBOARD_BIGIQ_PY_DIR/cluster_ve_os.py \
                       --ha-type $BIGIQ_HA_TYPE \
                       --num-bigiqs $NUM_BIGIQS
set +x
set +e
if [ "$BIGIQ_HA_TYPE" != "standalone" ]; then
    echo "Sleeping 60 seconds until BIG-IQs are clustered"
    sleep 60
fi


