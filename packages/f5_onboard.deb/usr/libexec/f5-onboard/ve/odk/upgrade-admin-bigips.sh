#!/bin/bash
source odk-utils
source f5-onboard-utils

# Gather necessary configuration
BIGIP_IMAGE=`f5-onboard-get-state clusters admin1 BIGIP_IMAGE`
NUM_BIGIPS=`f5-onboard-get-state clusters admin1 NUM_BIGIPS`

# Determine if image has a hotfix patch.  If so, perform upgrade
IFS='-' read -a image_components <<< "$BIGIP_IMAGE"
if [ -n "${image_components[3]}" ]; then
    base_full=${image_components[1]}
    hotfix_build=${image_components[3]}
    IFS='.' read -a base_components <<< "$base_full"
    base_version="${base_components[0]}.${base_components[1]}.${base_components[2]}"
    base_build="${base_components[3]}.${base_components[4]}.${base_components[5]}"

    set -e # exit on error
    set -x # echo commands
    stdbuf -o 0 -e 0 \
      python $F5_ONBOARD_BIGIP_PY_DIR/upgrade.py \
                                --num-bigips $NUM_BIGIPS \
                                --base-version $base_version \
                                --base-build $base_build \
                                --hotfix-build $hotfix_build
    set +x
    set +e
fi

