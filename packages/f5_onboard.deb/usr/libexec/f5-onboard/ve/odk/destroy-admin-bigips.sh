#!/bin/bash
source odk-utils
source f5-onboard-utils

NETWORK_TYPE=`odk-get-state deployments odk-maas NETWORK_TYPE`
HA_TYPE=`f5-onboard-get-state clusters admin1 HA_TYPE`
NUM_BIGIPS=`f5-onboard-get-state clusters admin1 NUM_BIGIPS`

if [ -z "$NUM_BIGIPS" ]; then
    if [ "$HA_TYPE" == "standalone" ]; then
        NUM_BIGIPS=1
    elif [ "$HA_TYPE" == "pair" ]; then
        NUM_BIGIPS=2
    elif [ "$HA_TYPE" == "scalen" ]; then
        if [ -z "$NUM_BIGIPS" ]; then
            NUM_BIGIPS=$SCALEN_DEFAULT_SIZE
        fi
    else
        echo "Invalid HA type!"
        exit 1
    fi
fi

# not implemented yet
#if [ "$NETWORK_TYPE" = "vlan" ]; then
#    echo "`date` Detaching BIG-IP from VLAN trunk."
#    set -x
#    ./odk-detach-bigips-to-vlan-trunk
#    set +x
#fi

# Destroy each of the BIG-IP instances
odkcmd $F5_ONBOARD_LIBEXEC_DIR/ve/openstack/destroy-admin-bigips.sh \
                               --bigip-index 1 \
                               --num-bigips $NUM_BIGIPS
