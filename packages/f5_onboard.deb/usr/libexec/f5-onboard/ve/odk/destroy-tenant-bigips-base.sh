#!/bin/bash
source odk-utils
source f5-onboard-utils


SCALEN_SIZE=4
BIGIP_IMAGE='BIGIP-11.5.0.0.0.221-OpenStack.qcow2'
# Parse command line switches
while [ $# -gt 0 ]; do
   case "$1" in
       --odk-tenant-index) ODK_TENANT_INDEX=$2 ; shift 2 ;;
       --ha-type)      HA_TYPE=$2 ; shift 2 ;;
       --bigip-image)  BIGIP_IMAGE=$2 ; shift 2 ;;
       *)    shift 1;;
   esac
done

if [ -z "$ODK_TENANT_INDEX" ]; then
    echo "No tenant index specified"
    exit 1
fi

# convert ha type to number of big-ips
if [ "$HA_TYPE" == "standalone" ]; then
    num_bigips=1
elif [ "$HA_TYPE" == "pair" ]; then
    num_bigips=2
elif [ "$HA_TYPE" == "scalen" ]; then
    num_bigips=$SCALEN_SIZE
else
    echo "Invalid HA type!"
    exit 1
fi

# Gather necessary configuration
DATA_NET_TOPOLOGY=`odk-get-state deployments odk-maas DATA_NET_TOPOLOGY`
EXT_NET_TOPOLOGY=`odk-get-state deployments odk-maas EXT_NET_TOPOLOGY`
if [ "$DATA_NET_TOPOLOGY" = "combined" ]; then
    if [ "$EXT_NET_TOPOLOGY" = "combined" ]; then
        DATA_CIDR=`odk-get-conf deployments odk-maas ext-net-cidr`
        DATA_START=`odk-get-conf deployments odk-maas ext-data-net-start`
        DATA_END=`odk-get-conf deployments odk-maas ext-data-net-end`
    else
        DATA_CIDR=`odk-get-conf deployments odk-maas mgmt-data-net-cidr`
        DATA_START=`odk-get-conf deployments odk-maas mgmt-data-net-start`
        DATA_END=`odk-get-conf deployments odk-maas mgmt-data-net-end`
    fi
else
    DATA_CIDR="10.30.30.0/24"
    DATA_START="10.30.30.200"
    DATA_END="10.30.30.250"
fi

OPT_CLEAN=--verbose\ --check\ --cleanup-only

set -e # exit on error

if [ "$HA_TYPE" != "standalone" ]; then
    odk-network $OPT_CLEAN \
                --odk-tenant-index $ODK_TENANT_INDEX \
                --network-index 12 \
                --network-name bigip_mirror

    odk-network $OPT_CLEAN \
                --odk-tenant-index $ODK_TENANT_INDEX \
                --network-index 11 \
                --network-name bigip_ha
fi

odk-network $OPT_CLEAN \
            --odk-tenant-index $ODK_TENANT_INDEX \
            --network-index 10 \
            --network-name bigip_mgmt

set +e
