#!/bin/bash
source odk-utils
source f5-onboard-utils

function show_usage {
    echo "Usage:"
    echo "f5-onboard-ve-odk deploy-tenant-bigips"
    echo "  --odk-tenant-index Which tenant"; \
    echo "  --bigip-image      Which BIG-IP to use"; \
    echo "                     Default: BIGIP-11.5.0.0.0.221-OpenStack.qcow2"; \
    echo "  --ha-type          Which High Availability type to use: standalone, pair, scalen"; \
    echo "                     Default: pair"; \
    echo "  --num-bigips       Number of big-ips to deploy for scalen mode"; \
    echo "                     Default: 4"; \
    echo "  --sync-mode        Which Synchronization mode to use: replication or autosync"; \
    echo "                     Default: replication"; \
    echo "  --icontrol-config-mode objects or iapp"; \
    echo "                     Default: iapp"; \
}


BIGIP_IMAGE=BIGIP-11.5.0.0.0.221-OpenStack.qcow2
HA_TYPE=pair
SYNC_MODE=replication
ICONTROL_CONFIG_MODE=iapp
# Parse command line switches
while [ $# -gt 0 ]; do
   case "$1" in
       --odk-tenant-index) ODK_TENANT_INDEX=$2 ; shift 2 ;;
       --bigip-image)  BIGIP_IMAGE=$2 ; shift 2 ;;
       --ha-type)      HA_TYPE=$2 ; shift 2 ;;
       --num-bigips)   NUM_BIGIPS=$2 ; shift 2 ;;
       --sync-mode)    SYNC_MODE=$2 ; shift 2 ;;
       --icontrol-config-mode)    ICONTROL_CONFIG_MODE=$2 ; shift 2 ;;
       -h|help|--help) show_usage; exit 0;;
       *)              show_usage; exit 1;;
   esac
done

# Gather necessary configuration
TENANT_NAME="proj_$ODK_TENANT_INDEX"

#VNC_PROXY_ADDRESS=`odk-get-conf deployments odk-maas vnc-proxy-address`
#if [ "$VNC_PROXY_ADDRESS" != "" ]; then
#    VNC_OPT="--vnc-endpoint $VNC_PROXY_ADDRESS:6080"
#else
#    VNC_OPT=""
#fi

# convert ha type to number of big-ips
if [ "$HA_TYPE" == "standalone" ]; then
    NUM_BIGIPS=1
elif [ "$HA_TYPE" == "pair" ]; then
    NUM_BIGIPS=2
elif [ "$HA_TYPE" == "scalen" ]; then
    if [ -z "$NUM_BIGIPS" ]; then
        NUM_BIGIPS=$SCALEN_DEFAULT_SIZE
    fi
else
    echo "Invalid HA type!"
    show_usage
    exit 1
fi


# Helper function for licensing
function prepare_metadata_for_bigip {
    bigip_idx=$1

    # get license from file and then remove it
    license=`head -1 $F5_ONBOARD_CONF_DIR/startup.licenses`
    echo "Using license $license"
    tail -n +2 $F5_ONBOARD_CONF_DIR/startup.licenses \
         > $F5_ONBOARD_CONF_DIR/startup.licenses.left
    mv $F5_ONBOARD_CONF_DIR/startup.licenses.left \
         $F5_ONBOARD_CONF_DIR/startup.licenses

    # Populate metadata with license
    mkdir -p $F5_ONBOARD_TMP_DIR
    cat $F5_ONBOARD_LIB_DIR/config-templates/startup_metadata.json-template \
          | sed "s/\$key/$license/" \
          > $F5_ONBOARD_TMP_DIR/startup_metadata_$bigip_idx.json

    echo $license >> $F5_ONBOARD_CONF_DIR/startup.licenses.used
}

if [ -f $F5_ONBOARD_CONF_DIR/startup.licenses.used ]; then
    cat $F5_ONBOARD_CONF_DIR/startup.licenses.used \
          >> $F5_ONBOARD_CONF_DIR/startup.licenses
fi
> $F5_ONBOARD_CONF_DIR/startup.licenses.used
# Create each of the BIG-IP instances
for (( bigip_index=1; bigip_index<=$NUM_BIGIPS; bigip_index++ ))
do
    # this sets the license
    prepare_metadata_for_bigip $bigip_index
done

# The script writes the assigned floating-ips to the following file
# TODO: it should call f5-onboard-set-state
set -x
set -e # exit on error
odkcmd f5-onboard-ve-openstack deploy-tenant-bigips \
    --os-tenant-name $TENANT_NAME \
    --os-username user_$ODK_TENANT_INDEX \
    --os-password user_$ODK_TENANT_INDEX \
    --external-network-name proj_${ODK_TENANT_INDEX}_net_2_external \
    --internal-network-name proj_${ODK_TENANT_INDEX}_net_1_internal \
    --ha-type $HA_TYPE \
    --bigip-image $BIGIP_IMAGE \
    --num-bigips $NUM_BIGIPS
set +e
MGMT_IPS=`cat $F5_ONBOARD_TMP_DIR/bigip-addrs`

CLUSTER_NAME="${TENANT_NAME}-1"
f5-onboard-set-state deployments odk-maas-$TENANT_NAME CLUSTER_NAME=$CLUSTER_NAME
f5-onboard-set-state clusters $CLUSTER_NAME ODK_DEPLOYMENT=odk-maas
f5-onboard-set-state clusters $CLUSTER_NAME BIGIP_IMAGE=$BIGIP_IMAGE
f5-onboard-set-state clusters $CLUSTER_NAME HA_TYPE=$HA_TYPE
f5-onboard-set-state clusters $CLUSTER_NAME SYNC_MODE=$SYNC_MODE
f5-onboard-set-state clusters $CLUSTER_NAME NUM_BIGIPS=$NUM_BIGIPS
f5-onboard-set-state clusters $CLUSTER_NAME MGMT_IPS=$MGMT_IPS
f5-onboard-set-state clusters $CLUSTER_NAME ICONTROL_CONFIG_MODE=$ICONTROL_CONFIG_MODE

set -e # exit on error
odkcmd f5-onboard-ve-odk upgrade-tenant-bigips --odk-tenant-index $ODK_TENANT_INDEX

# we run this even for standalone mode because
# this configures the hostname and turns off strict 
# route domains
odkcmd f5-onboard-ve-odk cluster-tenant-bigips --odk-tenant-index $ODK_TENANT_INDEX

set +e
set +x

