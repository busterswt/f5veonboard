#!/bin/bash
source odk-utils
source f5-onboard-utils

BIGIP_IMAGE="BIGIP-11.5.0.0.0.221-OpenStack.qcow2"
HA_TYPE=pair

function show_usage {
    echo "Usage:" 
    echo "f5-onboard-ve-odk deploy-bigips-base"
    echo "  --ha-type          Which High Availability type to use: standalone, pair, scalen"; \
    echo "                     Default: pair"; \
    echo "  --bigip-image      Which BIG-IP to use"; \
    echo "                     Default: BIGIP-11.5.0.0.0.221-OpenStack.qcow2"; \
}

# Parse command line switches
while [ $# -gt 0 ]; do
   case "$1" in
       --ha-type)      HA_TYPE=$2 ; shift 2 ;;
       --bigip-image)  BIGIP_IMAGE=$2 ; shift 2 ;;
       help|--help)    show_usage; exit 0;;
       *)              show_usage; exit 1;;
   esac
done


# Gather necessary configuration using address helpers
OPT_NO_CLEAN=--verbose\ --check\ --no-cleanup
ML2_DRIVER=`odk-get-state deployments odk-maas ML2_DRIVER`
DATA_NET_TOPOLOGY=`odk-get-state deployments odk-maas DATA_NET_TOPOLOGY`
EXT_NET_TOPOLOGY=`odk-get-state deployments odk-maas EXT_NET_TOPOLOGY`
if [ "$DATA_NET_TOPOLOGY" = "combined" ]; then
    if [ "$EXT_NET_TOPOLOGY" = "combined" ]; then
        DATA_CIDR=`odk-get-conf deployments odk-maas ext-net-cidr`
        DATA_START=`odk-get-conf deployments odk-maas ext-data-net-start`
        DATA_END=`odk-get-conf deployments odk-maas ext-data-net-end`
    else
        DATA_CIDR=`odk-get-conf deployments odk-maas mgmt-data-net-cidr`
        DATA_START=`odk-get-conf deployments odk-maas mgmt-data-net-start`
        DATA_END=`odk-get-conf deployments odk-maas mgmt-data-net-end`
    fi
else
    DATA_CIDR="10.30.30.0/24"
    DATA_START="10.30.30.200"
    DATA_END="10.30.30.250"
fi

set -e # exit on error
set -x # echo commands

if [ "$ML2_DRIVER" = "odl" ]; then
    odk-provider-network $OPT_NO_CLEAN \
                     --network-name datanet \
                     --network-type local \
                     --subnet-cidr $DATA_CIDR \
                     --ip-pool-start $DATA_START \
                     --ip-pool-end $DATA_END
else
    odk-provider-network $OPT_NO_CLEAN \
                     --network-name datanet \
                     --network-type flat \
                     --physical-network physnet-data \
                     --subnet-cidr $DATA_CIDR \
                     --ip-pool-start $DATA_START \
                     --ip-pool-end $DATA_END
fi


odk-network $OPT_NO_CLEAN \
            --network-index 1 \
            --network-name bigip_mgmt

# bigip external network
odk-network $OPT_NO_CLEAN \
            --network-index 2 \
            --network-name bigip_external

# bigip internal network
odk-network $OPT_NO_CLEAN \
            --network-index 3 \
            --network-name bigip_internal

if [ "$HA_TYPE" != "standalone" ]; then
    # ha network
    odk-network $OPT_NO_CLEAN \
                --network-index 4 \
                --network-name bigip_ha

    # mirroring network
    odk-network $OPT_NO_CLEAN \
                --network-index 5 \
                --network-name bigip_mirror
fi

odk-admin-image $OPT_NO_CLEAN \
                --image $F5_ONBOARD_IMAGE_DIR/$BIGIP_IMAGE
set +x

