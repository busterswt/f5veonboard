#!/bin/bash

# Takes the tap side of the 
# bigip virtual inteface and remove it from the
# openstack integration bridge and place it on
# the bridge that allows vlan trunk access
# to the data network
source odk-utils
source f5-onboard-utils

NUM_MACHINES=`odk-get-state deployments odk-maas NUM_MACHINES`
DISTRO=`odk-get-state deployments odk-maas DISTRO`

if [ "$DISTRO" = "precise" ]; then
   bigip_port=`f5-onboard-get-conf singletons globals BIGIP_PORT_PRECISE`
else
   bigip_port=`f5-onboard-get-conf singletons globals BIGIP_PORT`
fi
if [ -n "$bigip_port" ]; then
    BIGIP_BRIDGE=br-bigips
else
    BIGIP_BRIDGE=br-data
fi

if [ $NUM_MACHINES = 2 ]
then
    NUM_COMPUTE=1
else
    NUM_COMPUTE=$(($NUM_MACHINES - 2))
fi

echo "Num compute machines: $NUM_COMPUTE"

KEYSTONE_ADDRESS=`get_keystone_address`
KEYSTONE_PASSWORD=`get_keystone_password`

# expand this template: $F5_ONBOARD_LIB_DIR/attach-bigips-to-vlan-trunk.template
# and execute in on the compute nodes
mkdir -p $F5_ONBOARD_TMP_DIR
echo "#!/bin/bash" \
         > $F5_ONBOARD_TMP_DIR/attach-bigips-to-vlan-trunk
echo export OS_AUTH_URL=http://$KEYSTONE_ADDRESS:5000/v2.0 \
         >> $F5_ONBOARD_TMP_DIR/attach-bigips-to-vlan-trunk
echo export OS_PASSWORD=$KEYSTONE_PASSWORD \
         >> $F5_ONBOARD_TMP_DIR/attach-bigips-to-vlan-trunk
echo export BIGIP_BRIDGE=$BIGIP_BRIDGE \
         >> $F5_ONBOARD_TMP_DIR/attach-bigips-to-vlan-trunk
if [ -n "$bigip_port" ]; then
    echo export BIGIP_PORT=$bigip_port \
             >> $F5_ONBOARD_TMP_DIR/attach-bigips-to-vlan-trunk
fi
cat $F5_ONBOARD_LIB_DIR/attach-bigips-to-vlan-trunk.template \
         >> $F5_ONBOARD_TMP_DIR/attach-bigips-to-vlan-trunk

index=0
# subtract one to match 0 based index
NUM_COMPUTE=$(($NUM_COMPUTE - 1))
while [ $index -le $NUM_COMPUTE ]
do
    echo "Attaching on compute $index"
    odk_nc_scp $index $F5_ONBOARD_TMP_DIR/attach-bigips-to-vlan-trunk
    odk_nc $index chmod ug+x attach-bigips-to-vlan-trunk
    odk_nc $index ./attach-bigips-to-vlan-trunk
    index=$(($index + 1))
done
exit 0
