#!/bin/bash
source odk-utils
source f5-onboard-utils


SCALEN_SIZE=4
BIGIP_IMAGE='BIGIP-11.5.0.0.0.221-OpenStack.qcow2'
# Parse command line switches
while [ $# -gt 0 ]; do
   case "$1" in
       --ha-type)      HA_TYPE=$2 ; shift 2 ;;
       --bigip-image)  BIGIP_IMAGE=$2 ; shift 2 ;;
       *)    shift 1;;
   esac
done

# Gather necessary configuration
$(odk_creds)

# convert ha type to number of big-ips
if [ "$HA_TYPE" == "standalone" ]; then
    num_bigips=1
elif [ "$HA_TYPE" == "pair" ]; then
    num_bigips=2
elif [ "$HA_TYPE" == "scalen" ]; then
    num_bigips=$SCALEN_SIZE
else
    echo "Invalid HA type!"
    exit 1
fi

DATA_NET_TOPOLOGY=`odk-get-state deployments odk-maas DATA_NET_TOPOLOGY`
EXT_NET_TOPOLOGY=`odk-get-state deployments odk-maas EXT_NET_TOPOLOGY`
if [ "$DATA_NET_TOPOLOGY" = "combined" ]; then
    if [ "$EXT_NET_TOPOLOGY" = "combined" ]; then
        DATA_CIDR=`odk-get-conf deployments odk-maas ext-net-cidr`
        DATA_START=`odk-get-conf deployments odk-maas ext-data-net-start`
        DATA_END=`odk-get-conf deployments odk-maas ext-data-net-end`
    else
        DATA_CIDR=`odk-get-conf deployments odk-maas mgmt-data-net-cidr`
        DATA_START=`odk-get-conf deployments odk-maas mgmt-data-net-start`
        DATA_END=`odk-get-conf deployments odk-maas mgmt-data-net-end`
    fi
else
    DATA_CIDR="10.30.30.0/24"
    DATA_START="10.30.30.200"
    DATA_END="10.30.30.250"
fi

OPT_CLEAN=--verbose\ --check\ --cleanup-only

set -e # exit on error
odk-admin-image $OPT_CLEAN \
    --image $F5_ONBOARD_IMAGE_DIR/$BIGIP_IMAGE

if [ "$HA_TYPE" != "standalone" ]; then
    odk-network $OPT_CLEAN \
                --network-index 5 \
                --network-name bigip_mirror

    odk-network $OPT_CLEAN \
                --network-index 4 \
                --network-name bigip_ha
fi
odk-network $OPT_CLEAN \
            --network-index 3 \
            --network-name bigip_internal

odk-network $OPT_CLEAN \
            --network-index 2 \
            --network-name bigip_external

odk-network $OPT_CLEAN \
            --network-index 1 \
            --network-name bigip_mgmt

odk-provider-network $OPT_CLEAN \
                     --network-name datanet \
                     --network-type flat \
                     --physical-network physnet-data \
                     --subnet-cidr $DATA_CIDR \
                     --ip-pool-start $DATA_START \
                     --ip-pool-end $DATA_END

set +e
