#!/bin/bash
source odk-utils
source f5-onboard-utils

NETWORK_TYPE=`odk-get-state deployments odk-maas NETWORK_TYPE`

function show_usage {
    echo "Usage:"
    echo "f5-onboard-ve-odk destroy-tenant-bigips"
    echo "  --odk-tenant-index     Which tenant"; \
}


# Parse command line switches
while [ $# -gt 0 ]; do
   case "$1" in
       --odk-tenant-index) ODK_TENANT_INDEX=$2 ; shift 2 ;;
       -h|help|--help) show_usage; exit 0;;
       *)              show_usage; exit 1;;
   esac
done

TENANT_NAME="proj_$ODK_TENANT_INDEX"
CLUSTER_NAME="${TENANT_NAME}-1"
NUM_BIGIPS=`f5-onboard-get-state clusters $CLUSTER_NAME NUM_BIGIPS`

# not implemented yet
#if [ "$NETWORK_TYPE" = "vlan" ]; then
#    echo "`date` Detaching BIG-IP from VLAN trunk."
#    set -x
#    ./odk-detach-bigips-to-vlan-trunk
#    set +x
#fi

# Destroy each of the BIG-IP instances
odkcmd $F5_ONBOARD_LIBEXEC_DIR/ve/openstack/destroy-tenant-bigips.sh \
    --os-tenant-name $TENANT_NAME \
    --os-username user_$ODK_TENANT_INDEX \
    --os-password user_$ODK_TENANT_INDEX \
    --external-network-name proj_${ODK_TENANT_INDEX}_net_2_external \
    --internal-network-name proj_${ODK_TENANT_INDEX}_net_1_internal \
    --bigip-index 1 \
    --num-bigips $NUM_BIGIPS
