LIBEXEC=$F5_ONBOARD_LIBEXEC_DIR/ve/odk

function show_usage {
    echo "Usage: "
    echo "f5-onboard-ve-odk deploy-admin-bigiqs-base | \\"
    echo "                  deploy-admin-bigiqs | \\"
    echo "                  upgrade-admin-bigiqs | \\"
    echo "                  cluster-admin-bigiqs | \\"
    echo "                  deploy-admin-bigips-base | \\"
    echo "                  deploy-tenant-bigips-base | \\"
    echo "                  deploy-admin-bigips | \\"
    echo "                  deploy-tenant-bigips | \\"
    echo "                  upgrade-admin-bigips | \\"
    echo "                  upgrade-tenant-bigips | \\"
    echo "                  cluster-admin-bigips | \\"
    echo "                  cluster-tenant-bigips | \\"
    echo "                  attach-bigips-to-vlan-trunk | \\"
    echo "                  destroy-admin-bigips | \\"
    echo "                  destroy-tenant-bigips | \\"
    echo "                  destroy-admin-bigips-base | \\"
    echo "                  destroy-tenant-bigips-base | \\"
    echo "                  destroy-admin-bigiqs "
    echo "                  destroy-admin-bigiqs-base | \\"
}
function run_command {
  # Parse sub command
   case "$1" in
     deploy-admin-bigiqs-base)   shift 1;$LIBEXEC/deploy-admin-bigiqs-base.sh $*;;
     deploy-admin-bigiqs)   shift 1;$LIBEXEC/deploy-admin-bigiqs.sh $*;;
     upgrade-admin-bigiqs)   shift 1;$LIBEXEC/upgrade-admin-bigiqs.sh $*;;
     cluster-admin-bigiqs)   shift 1;$LIBEXEC/cluster-admin-bigiqs.sh $*;;
     deploy-admin-bigips-base)   shift 1;$LIBEXEC/deploy-admin-bigips-base.sh $*;;
     deploy-tenant-bigips-base)   shift 1;$LIBEXEC/deploy-tenant-bigips-base.sh $*;;
     deploy-admin-bigips)   shift 1;$LIBEXEC/deploy-admin-bigips.sh $*;;
     deploy-tenant-bigips)   shift 1;$LIBEXEC/deploy-tenant-bigips.sh $*;;
     upgrade-admin-bigips)   shift 1;$LIBEXEC/upgrade-admin-bigips.sh $*;;
     upgrade-tenant-bigips)   shift 1;$LIBEXEC/upgrade-tenant-bigips.sh $*;;
     cluster-admin-bigips)   shift 1;$LIBEXEC/cluster-admin-bigips.sh $*;;
     cluster-tenant-bigips)   shift 1;$LIBEXEC/cluster-tenant-bigips.sh $*;;
     attach-bigips-to-vlan-trunk)   shift 1;$LIBEXEC/attach-bigips-to-vlan-trunk.sh $*;;
     destroy-admin-bigips)  shift 1;$LIBEXEC/destroy-admin-bigips.sh $*;;
     destroy-tenant-bigips)  shift 1;$LIBEXEC/destroy-tenant-bigips.sh $*;;
     destroy-admin-bigips-base)  shift 1;$LIBEXEC/destroy-admin-bigips-base.sh $*;;
     destroy-tenant-bigips-base)  shift 1;$LIBEXEC/destroy-tenant-bigips-base.sh $*;;
     destroy-admin-bigiqs)  shift 1;$LIBEXEC/destroy-admin-bigiqs.sh $*;;
     destroy-admin-bigiqs-base)  shift 1;$LIBEXEC/destroy-admin-bigiqs-base.sh $*;;
     *)               echo "bad arg: $1"; show_usage;exit 1;;
   esac
   retval=$?
   exit $retval
}


