#!/bin/bash
source odk-utils
source f5-onboard-utils

function show_usage {
    echo "Usage:"
    echo "f5-onboard-ve-odk deploy-bigips"
    echo "  --bigip-image      Which BIG-IP to use"; \
    echo "                     Default: BIGIP-11.5.0.0.0.221-OpenStack.qcow2"; \
    echo "  --ha-type          Which High Availability type to use: standalone, pair, scalen"; \
    echo "                     Default: pair"; \
    echo "  --num-bigips       Number of big-ips to deploy for scalen mode"; \
    echo "                     Default: 4"; \
    echo "  --sync-mode        Which Synchronization mode to use: replication or autosync"; \
    echo "                     Default: replication"; \
    echo "  --icontrol-config-mode   config method to use: iapp or object"; \
    echo "                     Default: iapp"; \
}


BIGIP_IMAGE=BIGIP-11.5.0.0.0.221-OpenStack.qcow2
HA_TYPE=pair
SYNC_MODE=replication
ICONTROL_CONFIG_MODE=iapp
# Parse command line switches
while [ $# -gt 0 ]; do
   case "$1" in
       --bigip-image)  BIGIP_IMAGE=$2 ; shift 2 ;;
       --ha-type)      HA_TYPE=$2 ; shift 2 ;;
       --num-bigips)   NUM_BIGIPS=$2 ; shift 2 ;;
       --sync-mode)    SYNC_MODE=$2 ; shift 2 ;;
       --icontrol-config-mode)    ICONTROL_CONFIG_MODE=$2 ; shift 2 ;;
       -h|help|--help) show_usage; exit 0;;
       *)              show_usage; exit 1;;
   esac
done

# Gather necessary configuration
NETWORK_TYPE=`odk-get-state deployments odk-maas NETWORK_TYPE`
#VNC_PROXY_ADDRESS=`odk-get-conf deployments odk-maas vnc-proxy-address`
#if [ "$VNC_PROXY_ADDRESS" != "" ]; then
#    VNC_OPT="--vnc-endpoint $VNC_PROXY_ADDRESS:6080"
#else
#    VNC_OPT=""
#fi

# convert ha type to number of big-ips
if [ "$HA_TYPE" == "standalone" ]; then
    NUM_BIGIPS=1
elif [ "$HA_TYPE" == "pair" ]; then
    NUM_BIGIPS=2
elif [ "$HA_TYPE" == "scalen" ]; then
    if [ -z "$NUM_BIGIPS" ]; then
        NUM_BIGIPS=$SCALEN_DEFAULT_SIZE
    fi
else
    echo "Invalid HA type!"
    show_usage
    exit 1
fi


# Helper function for licensing
function prepare_metadata_for_bigip {
    bigip_idx=$1

    # get license from file and then remove it
    license=`head -1 $F5_ONBOARD_CONF_DIR/startup.licenses`
    echo "Using license $license"
    tail -n +2 $F5_ONBOARD_CONF_DIR/startup.licenses \
         > $F5_ONBOARD_CONF_DIR/startup.licenses.left
    mv $F5_ONBOARD_CONF_DIR/startup.licenses.left \
         $F5_ONBOARD_CONF_DIR/startup.licenses

    # Populate metadata with license
    mkdir -p $F5_ONBOARD_TMP_DIR
    cat $F5_ONBOARD_LIB_DIR/config-templates/startup_metadata.json-template \
          | sed "s/\$key/$license/" \
          > $F5_ONBOARD_TMP_DIR/startup_metadata_$bigip_idx.json

    echo $license >> $F5_ONBOARD_CONF_DIR/startup.licenses.used
}

# Stop the plug-in from talking to BIG-IPs as they are being onboarded.
# Otherwise the plug-in might attempt to save the configuration while
# we are in the middle of setting it up
echo -n "Removing BIG-IP ip addresses from running plug-in config "
echo "to avoid conflict with onboarding...."
odkcmd f5-onboard-lbaas unconfig-bigip-plugin

if [ -f $F5_ONBOARD_CONF_DIR/startup.licenses.used ]; then
    cat $F5_ONBOARD_CONF_DIR/startup.licenses.used \
          >> $F5_ONBOARD_CONF_DIR/startup.licenses
fi
> $F5_ONBOARD_CONF_DIR/startup.licenses.used
# Create each of the BIG-IP instances
for (( bigip_index=1; bigip_index<=$NUM_BIGIPS; bigip_index++ ))
do
    # this sets the license
    prepare_metadata_for_bigip $bigip_index
done

# The script writes the assigned floating-ips to the following file
# TODO: it should call f5-onboard-set-state
set -x
set -e # exit on error
f5-onboard-set-state deployments odk-maas CLUSTER_NAME=admin1
f5-onboard-set-state clusters admin1 ODK_DEPLOYMENT=odk-maas
f5-onboard-set-state clusters admin1 BIGIP_IMAGE=$BIGIP_IMAGE
f5-onboard-set-state clusters admin1 HA_TYPE=$HA_TYPE
f5-onboard-set-state clusters admin1 SYNC_MODE=$SYNC_MODE
odkcmd f5-onboard-ve-openstack deploy-admin-bigips \
                                 --ha-type $HA_TYPE \
                                 --bigip-image $BIGIP_IMAGE \
                                 --num-bigips $NUM_BIGIPS
set +e
MGMT_IPS=`cat $F5_ONBOARD_TMP_DIR/bigip-addrs`

f5-onboard-set-state clusters admin1 NUM_BIGIPS=$NUM_BIGIPS
f5-onboard-set-state clusters admin1 MGMT_IPS=$MGMT_IPS
f5-onboard-set-state clusters admin1 ICONTROL_CONFIG_MODE=$ICONTROL_CONFIG_MODE

set -e # exit on error
odkcmd f5-onboard-ve-odk upgrade-admin-bigips

# we run this even for standalone mode because
# this configures the hostname and turns off strict 
# route domains
odkcmd f5-onboard-ve-odk cluster-admin-bigips

if [ "$NETWORK_TYPE" = "vlan" ]; then
    echo "`date` Attaching BIG-IP to VLAN trunk."
    odkcmd f5-onboard-ve-odk attach-bigips-to-vlan-trunk
    #echo -n "Press return after fixing BIG-IP Vlan trunk: "
    #read line
fi

odkcmd f5-onboard-lbaas config-bigip-plugin
set +e

set +x

