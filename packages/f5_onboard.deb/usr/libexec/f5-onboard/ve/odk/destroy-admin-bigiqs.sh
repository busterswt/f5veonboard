#!/bin/bash
source odk-utils
source f5-onboard-utils

$(odk_creds)
NETWORK_TYPE=`odk-get-state deployments odk-maas NETWORK_TYPE`
NUM_BIGIQS=`f5-onboard-get-state clusters admin1 NUM_BIGIQS`

# Destroy each of the BIG-IQ instances
odkcmd $F5_ONBOARD_LIBEXEC_DIR/ve/openstack/destroy-admin-bigiqs.sh \
                               --bigiq-index 1 \
                               --num-bigiqs $NUM_BIGIQS
