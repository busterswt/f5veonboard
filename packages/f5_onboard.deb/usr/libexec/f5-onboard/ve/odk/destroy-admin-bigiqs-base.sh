#!/bin/bash
source odk-utils
source f5-onboard-utils

BIGIQ_IMAGE="BIG-IQ-4.5.0.0.0.7028-OpenStack.qcow2"

function show_usage {
    echo "Usage:"
    echo "f5-onboard-ve-odk destroy-bigiqs-base"
    echo "  --bigiq-image      Which BIG-IQ image to use"; \
    echo "                     Default: BIG-IQ-4.5.0.0.0.7028-OpenStack.qcow2"; \
}

# Parse command line switches
while [ $# -gt 0 ]; do
   case "$1" in
       --bigiq-image)  BIGIQ_IMAGE=$2 ; shift 2 ;;
       help|--help)    show_usage; exit 0;;
       *)              show_usage; exit 1;;
   esac
done


# Gather necessary configuration using address helpers
OPT_CLEAN=--verbose\ --check\ --cleanup-only

set -e # exit on error
odk-admin-image $OPT_CLEAN \
    --image $F5_ONBOARD_IMAGE_DIR/$BIGIQ_IMAGE

odk-network $OPT_CLEAN \
            --network-index 13 \
            --network-name bigiq_internal

odk-network $OPT_CLEAN \
            --network-index 12 \
            --network-name bigiq_external

odk-network $OPT_CLEAN \
            --network-index 11 \
            --network-name bigiq_mgmt

set +e
