#!/bin/bash
source f5-onboard-utils

function show_usage {
    echo "Usage: "
    echo "f5-onboard-ve-openstack destroy-bigips \\"
    echo "    --num-bigips <num> \\"
    echo "    --bigip-index <idx> (starting bigip index)"
}

# Parse command line switches
BIGIP_INDEX=1
while [ $# -gt 0 ]; do
   case "$1" in
       --num-bigips)     NUM_BIGIPS=$2 ; shift 2 ;;
       --bigip-index)    BIGIP_INDEX=$2 ; shift 2 ;;
       --help)           show_usage; exit 0;;
       *)                show_usage; exit 1;;
   esac
done

if [ -z "$NUM_BIGIPS" ]; then
    show_usage
    exit 1
fi

OPT_CLEAN=--verbose\ --check\ --cleanup-only

set -e # exit on error
set -x
python $F5_ONBOARD_BIGIP_PY_DIR/ve.py $OPT_CLEAN \
                                 --bigip-index $BIGIP_INDEX \
                                 --num-bigips $NUM_BIGIPS
