#!/bin/bash
source f5-onboard-utils

set -e # exit on error

function show_usage {
    echo "Usage: "
    echo "f5-onboard-ve-openstack deploy-tenant-bigips \\"
    echo "    --os-tenant-name <name> \\"
    echo "    --os-username <un> \\"
    echo "    --os-password <pw> \\"
    echo "    --external-network-name <enn> \\"
    echo "    --internal-network-name <inn> \\"
    echo "    --bigip-image <img> \\"
    echo "    --ha-type scalen pair standalone \\"
    echo "    --num-bigips <num> \\"
    echo "    --bigip-index <idx> (starting bigip index)"
}

# Parse command line switches
BIGIP_INDEX=1
while [ $# -gt 0 ]; do
   case "$1" in
       --os-tenant-name)     TENANT_NAME=$2 ; shift 2 ;;
       --os-username) TENANT_USERNAME=$2 ; shift 2 ;;
       --os-password) TENANT_PASSWORD=$2 ; shift 2 ;;
       --external-network-name) EXTERNAL_NETWORK_NAME=$2 ; shift 2 ;;
       --internal-network-name) INTERNAL_NETWORK_NAME=$2 ; shift 2 ;;
       --ha-type)         HA_TYPE=$2 ; shift 2 ;;
       --bigip-image)     BIGIP_IMAGE=$2 ; shift 2 ;;
       --num-bigips)      NUM_BIGIPS=$2 ; shift 2 ;;
       --bigip-index)     BIGIP_INDEX=$2 ; shift 2 ;;
       *)    show_usage; exit 1;;
   esac
done


if [ "$HA_TYPE" == "standalone" ]; then
    NUM_BIGIPS=1
elif [ "$HA_TYPE" == "pair" ]; then
    NUM_BIGIPS=2
elif [ "$HA_TYPE" == "scalen" ]; then
    if [ -z "$NUM_BIGIPS" ]; then
        NUM_BIGIPS=$SCALEN_DEFAULT_SIZE
    fi
else
    show_usage
    echo "Invalid HA type!"
    exit 1
fi


if [ -z "$TENANT_NAME" -o \
     -z "$TENANT_PASSWORD" -o \
     -z "$BIGIP_IMAGE" ]; then
    show_usage
    exit 1
fi

OPT_NO_CLEAN=--verbose\ --check\ --no-cleanup

set -x # verbose
mkdir -p $F5_ONBOARD_STATE_DIR
python $F5_ONBOARD_BIGIP_PY_DIR/ve_tenant.py $OPT_NO_CLEAN \
                       --os-tenant-name $TENANT_NAME \
                       --os-username $TENANT_USERNAME \
                       --os-password $TENANT_PASSWORD \
                       --external-network-name $EXTERNAL_NETWORK_NAME \
                       --internal-network-name $INTERNAL_NETWORK_NAME \
                       --bigip-image $BIGIP_IMAGE \
                       --ha-type $HA_TYPE \
                       --num-bigips $NUM_BIGIPS \
                       --bigip-index $BIGIP_INDEX
set +x
set +e
