LIBEXEC=$F5_ONBOARD_LIBEXEC_DIR/ve/openstack

function show_usage {
    echo "Usage: "
    echo -n "f5-onboard-ve-openstack <deploy-bigips | destroy-bigips "
    echo -n "| deploy-bigiqs | destroy-bigiqs "
    echo "| patch-image <args>"
}

function run_command {
   if [ -z "$1" ]; then
       show_usage
       exit 1
   fi
  # Parse sub command
   case "$1" in
     deploy-admin-bigips)  shift 1;$LIBEXEC/deploy-admin-bigips.sh $*;;
     deploy-tenant-bigips)  shift 1;$LIBEXEC/deploy-tenant-bigips.sh $*;;
     destroy-admin-bigips)  shift 1;$LIBEXEC/destroy-admin-bigips.sh $*;;
     destroy-tenant-bigips)  shift 1;$LIBEXEC/destroy-tenant-bigips.sh $*;;
     deploy-admin-bigiqs)  shift 1;$LIBEXEC/deploy-admin-bigiqs.sh $*;;
     destroy-admin-bigiqs)  shift 1;$LIBEXEC/destroy-admin-bigiqs.sh $*;;
     patch-image)  shift 1;$LIBEXEC/patch-image.sh $*;;
     *) echo "bad arg: $1"; show_usage; exit 1;;
   esac
   retval=$?
   exit $retval
}

