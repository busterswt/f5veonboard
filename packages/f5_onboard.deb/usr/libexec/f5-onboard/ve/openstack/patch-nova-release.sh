#!/bin/bash
source odk-utils

function find_machines() {
    NUM_MACHINES=`odk-get-state deployments odk-maas NUM_MACHINES`
    SERVICESMACHINE=-1
    NETWORKMACHINE=-1
    COMPUTEMACHINES=()
    words=$(juju status | grep -e \"[^\"]*\": -e dns-name)
    for word in $words
    do
        if `echo $word | grep dns-name > /dev/null`
        then
            continue
        fi
        if `echo $word | grep \"[^\"]*\" > /dev/null`
        then
            curmachine=`echo $word | grep \"[^\"]*\" | sed 's/\"\([^\"]*\)\":/\1/'`
        fi
        if `echo $word | grep services > /dev/null`
        then
           if [ $NUM_MACHINES -ge 3 ]; then
               SERVICESMACHINE=$curmachine
           fi
        fi
        if `echo $word | grep network > /dev/null`
        then
           NETWORKMACHINE=$curmachine
        fi
        if `echo $word | grep compute > /dev/null`
        then
           # If we only have 2 machines then we will use the compute machine
           # as the services machine as well.
           if [ $NUM_MACHINES -eq 2 ]; then
               SERVICESMACHINE=$curmachine
           fi
           COMPUTEMACHINES+=("$curmachine")
        fi
    done
}

echo ODK_DEPLOYER is $ODK_DEPLOYER
if [ "$ODK_DEPLOYER" = "juju" ]; then
    find_machines
    echo "Num compute: ${#COMPUTEMACHINES[*]}"
    for (( nova_idx=0; nova_idx < ${#COMPUTEMACHINES[*]}; nova_idx++ ))
    do
        #JUJU_NOVA_TARGET="${COMPUTEMACHINES[$nova_idx]}"
        odk_nc $nova_idx 'echo "[Nova]" > /tmp/delme'
        odk_nc $nova_idx 'echo "vendor = Red Hat" >> /tmp/delme'
        odk_nc $nova_idx 'echo "product = Bochs" >> /tmp/delme'
        odk_nc $nova_idx 'echo "package = RHEL 6.3.0 PC" >> /tmp/delme'
        odk_nc $nova_idx sudo mv /tmp/delme /etc/nova/release
        odk_nc $nova_idx sudo service nova-compute restart
    done
fi
if [ $ODK_DEPLOYER = "packstack" ]; then
    odk_nc 0 'echo "[Nova]" > /etc/nova/release'
    odk_nc 0 'echo "vendor = Red Hat" >> /etc/nova/release'
    odk_nc 0 'echo "product = Bochs" >> /etc/nova/release'
    odk_nc 0 'echo "package = RHEL 6.3.0 PC" >> /etc/nova/release'
    if [ -f /usr/bin/systemctl ]; then
        odk_nc 0 systemctl restart openstack-nova-compute
    else
        odk_nc 0 service openstack-nova-compute restart
    fi
fi
echo "Restarting nova-consoleauth on network gateway"
odk_ng service nova-consoleauth restart

