badusage=false

# There needs to be a file parameter.
if [ $# -lt 2 ]; then
    badusage=true
else
    # The file parameter must end with .qcow2
    oldfile=$1
    echo $oldfile | grep -e'\(.*\)\.qcow2'
    if [ $? -ne 0 ]
    then
        badusage=true
    fi
fi


if $badusage
then
    echo "usage: ./inject-bigip-startup <image.qcow2> <startup-file>"
    echo "The image file name must end with .qcow2"
    echo ""
    echo "Example sudo ./inject-bigip-startup BIGIP-11.4.1.608.0.qcow2 startup"
    echo ""
    exit 1
fi

newfile=`echo $oldfile | sed 's/\(.*\)\.qcow2/\1-OpenStack.qcow2/'`


set -xe
echo Running apt-get update....
apt-get update > /dev/null
echo Running apt-get install qemu-utils lvm2
apt-get install qemu-utils lvm2
cp $oldfile $newfile
modprobe nbd max_part=32
sleep 2
qemu-nbd --connect=/dev/nbd0 `pwd`/$newfile
sleep 2
pvscan
sleep 2
vgchange -ay
sleep 2
mkdir -p /mnt/bigip-config

echo "/dev/vg-db-hda/set.1._config should be linked to /dev/dm-6 in the following output:"
ls -l /dev/vg-db-hda/set.1._config
mount /dev/dm-6 /mnt/bigip-config/

cp $2 /mnt/bigip-config
sleep 2
umount /mnt/bigip-config
sleep 2
vgchange -an
sleep 2
qemu-nbd -d /dev/nbd0
sleep 2
set +xe

