#!/bin/bash
source f5-onboard-utils

set -e # exit on error

function show_usage {
    echo "Usage: "
    echo "f5-onboard-ve-openstack deploy-bigiqs \\"
    echo "    --bigiq-image <img> \\"
    echo "    --ha-type scalen pair standalone \\"
    echo "    --num-bigiqs <num> \\"
    echo "    --bigiq-index <idx> (starting bigiq index)"
}

# Parse command line switches
BIGIQ_INDEX=1
while [ $# -gt 0 ]; do
   case "$1" in
       --ha-type)        HA_TYPE=$2 ; shift 2 ;;
       --bigiq-image)    BIGIQ_IMAGE=$2 ; shift 2 ;;
       --num-bigiqs)     NUM_BIGIQS=$2 ; shift 2 ;;
       --bigiq-index)    BIGIQ_INDEX=$2 ; shift 2 ;;
       *)    show_usage; exit 1;;
   esac
done


if [ "$HA_TYPE" == "standalone" ]; then
    NUM_BIGIQS=1
elif [ "$HA_TYPE" == "pair" ]; then
    NUM_BIGIQS=2
elif [ "$HA_TYPE" == "scalen" ]; then
    if [ -z "$NUM_BIGIQS" ]; then
        NUM_BIGIQS=$BIGIQ_SCALEN_DEFAULT_SIZE
    fi
else
    show_usage
    echo "Invalid HA type!"
    exit 1
fi


if [ -z "$BIGIQ_IMAGE" ]; then
    show_usage
    exit 1
fi

OPT_NO_CLEAN=--verbose\ --check\ --no-cleanup

set -x # verbose
mkdir -p $F5_ONBOARD_STATE_DIR
python $F5_ONBOARD_BIGIQ_PY_DIR/ve.py $OPT_NO_CLEAN \
                       --bigiq-image $BIGIQ_IMAGE \
                       --num-bigiqs $NUM_BIGIQS \
                       --bigiq-index $BIGIQ_INDEX
set +x
set +e
