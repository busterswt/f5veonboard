#!/bin/bash
source f5-onboard-utils

function show_usage {
    echo "Usage: "
    echo "f5-onboard-ve-openstack destroy-bigiqs \\"
    echo "    --num-bigiqs <num> \\"
    echo "    --bigiq-index <idx> (starting bigiq index)"
}

# Parse command line switches
BIGIQ_INDEX=1
while [ $# -gt 0 ]; do
   case "$1" in
       --num-bigiqs)     NUM_BIGIQS=$2 ; shift 2 ;;
       --bigiq-index)    BIGIQ_INDEX=$2 ; shift 2 ;;
       --help)           show_usage; exit 0;;
       *)                show_usage; exit 1;;
   esac
done

if [ -z "$NUM_BIGIQS" ]; then
    show_usage
    exit 1
fi

OPT_CLEAN=--verbose\ --check\ --cleanup-only

set -e # exit on error
set -x
python $F5_ONBOARD_BIGIQ_PY_DIR/ve.py $OPT_CLEAN \
                                 --bigiq-index $BIGIQ_INDEX \
                                 --num-bigiqs $NUM_BIGIQS
