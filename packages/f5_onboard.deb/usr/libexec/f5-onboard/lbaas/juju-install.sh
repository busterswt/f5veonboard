#!/bin/bash
source odk-utils
source f5-onboard-utils

function restart_service_ncc {
    if [ -f /usr/bin/systemctl ]; then
        odk_ncc systemctl restart $1
    else
        odk_ncc service $1 restart
    fi
}

function enable_service_qg  {
    if [ -f /usr/bin/systemctl ]; then
        odk_ng systemctl enable $1
    else
        odk_ng service $1 enable
    fi
}

function restart_service_qg  {
    if [ -f /usr/bin/systemctl ]; then
        odk_ng systemctl restart $1
    else
        odk_ng service $1 restart
    fi
}

odk_ng dpkg -l | grep -s python-suds
if [ $? = 1 ]; then
    odk_ng apt-get install -y python-suds
fi
odk_ng dpkg -l | grep -s f5-bigip-common
if [ $? = 1 ]; then
    odk_ng_scp $F5_ONBOARD_LIB_DIR/lbaas/f5-bigip-common*deb
    odk_ng dpkg -i f5-bigip-common*.deb
fi
odk_ng dpkg -l | grep -s f5-oslbaasv1-agent
if [ $? = 1 ]; then
    odk_ng_scp $F5_ONBOARD_LIB_DIR/lbaas/f5-oslbaasv1-agent*deb
    odk_ng dpkg -i f5-oslbaasv1-agent*.deb
fi

odk_na dpkg -l | grep -s f5-oslbaasv1-driver
if [ $? = 1 ]; then
    odk_na_scp $F5_ONBOARD_LIB_DIR/lbaas/f5-oslbaasv1-driver*deb
    odk_na dpkg -i f5-oslbaasv1-driver*.deb
fi

OPENSTACK_RELEASE=`odk-get-state deployments odk-maas OPENSTACK_RELEASE`
if [ "$OPENSTACK_RELEASE" = "juno" -o "$OPENSTACK_RELEASE" = "icehouse" ]; then
    juju set neutron-api service-providers=service_provider=LOADBALANCER:f5:f5.oslbaasv1driver.drivers.plugin_driver.F5PluginDriver:default,service_provider=VPN:openswan:neutron.services.vpn.service_drivers.ipsec.IPsecVPNDriver:default,service_provider=FIREWALL:Iptables:neutron.agent.linux.iptables_firewall.OVSHybridIptablesFirewallDriver:default
else 
    juju set neutron-api service-providers=service_provider=LOADBALANCER:f5:f5.oslbaasv1driver.drivers.plugin_driver.F5PluginDriver:default,service_provider=VPN:openswan:neutron_vpnaas.services.vpn.service_drivers.ipsec.IPsecVPNDriver:default,service_provider=FIREWALL:Iptables:neutron_fwaas.agent.linux.iptables_firewall.OVSHybridIptablesFirewallDriver:default
fi
echo "configured f5 driver in neutron config (via juju)"
echo "waiting 90 secs for neutron to restart and be ready"
sleep 90
