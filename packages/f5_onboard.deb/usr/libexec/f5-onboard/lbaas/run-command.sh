LIBEXEC=$F5_ONBOARD_LIBEXEC_DIR/lbaas


function show_usage {
    _show_usage
}

function _show_usage {
    echo "Usage: "
    echo -n "f5-onboard-lbaas "
    echo -n "config-bigip-plugin | unconfig-bigip-plugin | get-bigip-plugin-config"
    echo "<args>"
}

function run_command {
  # Parse sub command
   case "$1" in
     config-bigip-plugin)     shift 1;$LIBEXEC/config-bigip-plugin.sh $*;;
     unconfig-bigip-plugin)   shift 1;$LIBEXEC/unconfig-bigip-plugin.sh $*;;
     get-bigip-plugin-config) shift 1;$LIBEXEC/get-bigip-plugin-config.sh $*;;
     *)                       show_usage; exit 1;;
   esac
   exit $?
}


