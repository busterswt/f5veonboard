#!/bin/bash
source odk-utils
source f5-onboard-utils

function restart_service_ncc {
    if [ -f /usr/bin/systemctl ]; then
        odk_ncc systemctl restart $1
    else
        odk_ncc service $1 restart
    fi
}

function enable_service_qg  {
    if [ -f /usr/bin/systemctl ]; then
        odk_ng systemctl enable $1
    else
        odk_ng service $1 enable
    fi
}

function restart_service_qg  {
    if [ -f /usr/bin/systemctl ]; then
        odk_ng systemctl restart $1
    else
        odk_ng service $1 restart
    fi
}

odk_ng rpm -qa | grep -s python-suds
if [ $? = 1 ]; then
   odk_ng yum install -y python-suds
fi

odk_ng rpm -qa | grep -s f5-bigip-common
if [ $? = 1 ]; then
   odk_ng_scp $F5_ONBOARD_LIB_DIR/lbaas/f5-bigip-common*.rpm
   odk_ng rpm -i --replacefiles f5-bigip-common*.rpm
fi

odk_ng rpm -qa | grep -s f5-oslbaasv1-agent
if [ $? = 1 ]; then
   odk_ng_scp $F5_ONBOARD_LIB_DIR/lbaas/f5-oslbaasv1-agent*rpm
   odk_ng rpm -i --replacefiles f5-oslbaasv1-agent*rpm
fi

odk_ng rpm -qa | grep -s f5-bigip-lbaas
if [ $? = 1 ]; then
    odk_ng_scp $F5_ONBOARD_LIB_DIR/lbaas/f5-oslbaasv1-driver*rpm
    odk_ng rpm -i --replacefiles f5-oslbaasv1-driver*rpm
fi

echo Setting neutron to debug = True mode.
odk_ncc sed -i 's/^debug\ =\ False/debug\ =\ True/' /etc/neutron/neutron.conf
# icehouse
echo Add load balancer plugin to neutron.
odk_ncc sed -i 's/^service_plugins\ =neutron.services.l3_router.l3_router_plugin.L3RouterPlugin,neutron.services.firewall.fwaas_plugin.FirewallPlugin/service_plugins\ =neutron.services.l3_router.l3_router_plugin.L3RouterPlugin,neutron.services.firewall.fwaas_plugin.FirewallPlugin,neutron.services.loadbalancer.plugin.LoadBalancerPlugin/' /etc/neutron/neutron.conf
# juno
odk_ncc sed -i 's/^service_plugins\ =neutron.services.l3_router.l3_router_plugin.L3RouterPlugin/service_plugins\ =neutron.services.l3_router.l3_router_plugin.L3RouterPlugin,neutron.services.loadbalancer.plugin.LoadBalancerPlugin/' /etc/neutron/neutron.conf

echo Stop and Disable ha proxy service
odk_ncc systemctl stop neutron-lbaas-agent.service
odk_ncc systemctl disable neutron-lbaas-agent.service
$(odk_creds)
haproxy_agent_id=`neutron agent-list | grep neutron-lbaas-agent | cut -d' ' -f2`
echo neutron agent-delete $haproxy_agent_id
neutron agent-delete $haproxy_agent_id
echo Enable f5 load balancer driver as default, disable haproxy in neutron config
# pre-kilo
odk_ncc sed -i 's/^service_provider=LOADBALANCER:Haproxy/#service_provider=LOADBALANCER:Haproxy/' /etc/neutron/neutron.conf
# kilo
odk_ncc sed -i 's/^service_provider=LOADBALANCER:Haproxy:neutron_lbaas.services.loadbalancer.drivers.haproxy.plugin_driver.HaproxyOnHostPluginDriver:default/#\ service_provider=LOADBALANCER:Haproxy:neutron_lbaas.services.loadbalancer.drivers.haproxy.plugin_driver.HaproxyOnHostPluginDriver:default\\nservice_provider=LOADBALANCER:f5:f5.oslbaasv1driver.drivers.plugin_driver.F5PluginDriver:default/' /etc/neutron/neutron_lbaas.conf

echo Disable ha proxy in alternate config.
# pre-kilo
odk_ncc sed -i 's/^service_provider\ =\ LOADBALANCER/#service_provider\ =\ LOADBALANCER/' /usr/share/neutron/neutron-dist.conf
echo Configure f5 agent.
odk_ng sed -i 's/f5_vtep_selfip_name\ =\ vtep/f5_vtep_selfip_name\ =\ selfip.datanet/' /etc/neutron/f5-oslbaasv1-agent.ini
echo Restart neutron server.
restart_service_ncc neutron-server
sleep 3
echo Restart f5 agent.
restart_service_qg f5-oslbaasv1-agent
enable_service_qg f5-oslbaasv1-agent

echo Enable load balancer in openstack gui.
odk_ncc sed -i 's/enable_lb.*/enable_lb'\\\'':'\\'\\ \\''True,/' /etc/openstack-dashboard/local_settings
restart_service_ncc httpd

