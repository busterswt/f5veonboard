#!/bin/bash
source odk-utils
source f5-onboard-utils

F5_INI=/etc/neutron/f5-oslbaasv1-agent.ini
icontrol_hostname=`odk_ng cat $F5_INI | grep ^icontrol_hostname | cut -d'=' -f2 | tr -d '\r '`
if [ "$icontrol_hostname" = "192.168.1.245" ] || [ "$icontrol_hostname" = "" ]; then
    exit 0
else
    echo "configured"
    exit 1
fi
