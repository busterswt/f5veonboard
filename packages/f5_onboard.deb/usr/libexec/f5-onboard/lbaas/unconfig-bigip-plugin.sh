#!/bin/bash
source odk-utils
source f5-onboard-utils

KEYSTONE_ADDRESS=`get_keystone_address`
KEYSTONE_PASSWORD=`get_keystone_password`

# Remove lbaas configuration
F5_INI=/etc/neutron/f5-oslbaasv1-agent.ini
mkdir -p $F5_ONBOARD_TMP_DIR
echo "#!/bin/bash"  > $F5_ONBOARD_TMP_DIR/config-plugin
echo sed -i.bak \"s/\\\(icontrol_hostname\\s*=\\s*\\\).*/\\1/\" $F5_INI >> $F5_ONBOARD_TMP_DIR/config-plugin
echo sed -i.bak \"s/\\\(f5_ha_type\\s*=\\s*\\\).*/\\1pair/\" $F5_INI >> $F5_ONBOARD_TMP_DIR/config-plugin
echo sed -i.bak \"s/\\\(sync_mode\\s*=\\s*\\\).*/\\1replication/\" $F5_INI >> $F5_ONBOARD_TMP_DIR/config-plugin
echo sed -i.bak \"s/\\\(f5_vtep_folder\\s*=\\s*\\\).*/\\1None/\" $F5_INI >> $F5_ONBOARD_TMP_DIR/config-plugin
echo sed -i.bak \"s/\\\(f5_vtep_selfip_name\\s*=\\s*\\\).*/\\1None/\" $F5_INI >> $F5_ONBOARD_TMP_DIR/config-plugin
odk_ng_scp $F5_ONBOARD_TMP_DIR/config-plugin
odk_ng chmod ugo+x config-plugin
odk_ng ./config-plugin
odk_ng service f5-oslbaasv1-agent restart

# Delete current record of lbaas agent registration because it is based
# on IP address of the first big-ip, which can change on the next
# deployment.
script_name=$F5_ONBOARD_TMP_DIR/delete-lbaas-agent-registration
echo "#!/bin/bash"  > $script_name
echo export OS_AUTH_URL=http://$KEYSTONE_ADDRESS:5000/v2.0 >> $script_name
echo export OS_PASSWORD=$KEYSTONE_PASSWORD >> $script_name
echo export OS_TENANT_NAME=admin >> $script_name
echo export OS_USERNAME=admin >> $script_name
echo 'lbaas_agent=`neutron agent-list | grep Loadbalancer | grep node-network: | cut -c3-38`' >> $script_name
echo 'if [ -n "$lbaas_agent" ]; then neutron agent-delete $lbaas_agent; fi' >> $script_name
set -e
echo "Transferring delete registration script..."
odk_ng_scp $script_name
echo "Preparing delete registration script..."
odk_ng chmod ugo+x delete-lbaas-agent-registration
set +e
echo "Executing delete registration script..."
odk_ng ./delete-lbaas-agent-registration
retcode=$?
echo "unconfig-bigip-plugin: Return code is $retcode"
exit $retcode

