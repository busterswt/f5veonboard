# for devstack, we cannot directly install lbaas because neutron
# is not yet deployed so we alter the devstack script to run a script
# called f5-devstack-install.sh later before neutron is started.
DEFAULT_IP=`odk_default_ip`
odk_ng_scp $F5_ONBOARD_LIB_DIR/lbaas/f5-lbaas-devstack.tgz
odk_ng_scp $F5_ONBOARD_LIB_DIR/lbaas/f5-devstack-install.sh
odk_ng sed -i s/default_ip/$DEFAULT_IP/ f5-devstack-install.sh
odk_ng mv f5-lbaas-devstack.tgz f5-devstack-install.sh /tmp
sed -i "s#echo_summary \"Starting Neutron\"#echo_summary \"Starting Neutron\"\n/tmp/f5-devstack-install.sh $OPENSTACK_RELEASE#" \
           $ODK_TMP_DIR/devstack/stack.sh
sed -i s/10250/200000/ $ODK_TMP_DIR/devstack/stackrc
