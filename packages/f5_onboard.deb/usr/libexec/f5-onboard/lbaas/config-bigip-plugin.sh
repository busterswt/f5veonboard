#!/bin/bash
source odk-utils
source f5-onboard-utils

NETWORK_TYPE=`odk-get-state deployments odk-maas NETWORK_TYPE`
if [ "$NETWORK_TYPE" = "vlan" ]; then
    NETWORK_TYPE=""
fi

CLUSTER=`f5-onboard-get-state deployments odk-maas CLUSTER_NAME`
VCMP_ICONTROL_ADDRS=`f5-onboard-get-state clusters $CLUSTER VCMP_MGMT_IPS`
ICONTROL_ADDRS=`f5-onboard-get-state clusters $CLUSTER MGMT_IPS`
HA_TYPE=`f5-onboard-get-state clusters $CLUSTER HA_TYPE`
SYNC_MODE=`f5-onboard-get-state clusters $CLUSTER SYNC_MODE`
BIGIQ_MGMT_IPS=`f5-onboard-get-state clusters $CLUSTER BIGIQ_MGMT_IPS`
ICONTROL_CONFIG_MODE=`f5-onboard-get-state clusters $CLUSTER ICONTROL_CONFIG_MODE`

f5-onboard-get-state clusters $CLUSTER ICONTROL_CONFIG_MODE
NEUTRON_CONF=/etc/neutron/neutron.conf
F5_INI=/etc/neutron/f5-oslbaasv1-agent.ini

mkdir -p $F5_ONBOARD_TMP_DIR
echo OPENSTACK_KEYSTONE_URI="http:\\\\/\\\\/`get_keystone_address`\\:5000" > \
      $F5_ONBOARD_TMP_DIR/config-plugin
echo BIGIQ_MGMT_IPS=$BIGIQ_MGMT_IPS >> $F5_ONBOARD_TMP_DIR/config-plugin
echo ICONTROL_ADDRS=$ICONTROL_ADDRS >> $F5_ONBOARD_TMP_DIR/config-plugin
echo VCMP_ICONTROL_ADDRS=$VCMP_ICONTROL_ADDRS >> $F5_ONBOARD_TMP_DIR/config-plugin
echo HA_TYPE=$HA_TYPE >> $F5_ONBOARD_TMP_DIR/config-plugin
echo SYNC_MODE=$SYNC_MODE >> $F5_ONBOARD_TMP_DIR/config-plugin
echo NETWORK_TYPE=$NETWORK_TYPE >> $F5_ONBOARD_TMP_DIR/config-plugin
echo ICONTROL_CONFIG_MODE=$ICONTROL_CONFIG_MODE >> $F5_ONBOARD_TMP_DIR/config-plugin
cat $F5_ONBOARD_LIBEXEC_DIR/lbaas/config-bigip-plugin-template.sh >> $F5_ONBOARD_TMP_DIR/config-plugin

odk_ng_scp $F5_ONBOARD_TMP_DIR/config-plugin
# odk_ng will run a command on the neutron gateway
odk_ng chmod ugo+x config-plugin
odk_ng ./config-plugin
if [ "$ODK_DEPLOYER" = "devstack" ]; then
    [ ! -d /var/run/$proj ] && (sudo mkdir -p /var/run/$proj;sudo chmod ugo+wx /var/run/$proj)
    mkdir -p /opt/stack/neutron/log
    cd /opt/stack/neutron
    plugin=f5-oslbaasv1-agent
    nohup ./usr/bin/$plugin --log-file  /opt/stack/neutron/log/$plugin.log \
                      --config-file /etc/neutron/neutron.conf \
                      --config-file /etc/neutron/$plugin.ini &>/dev/null &
else
    odk_ng rm -f /var/log/neutron/f5-oslbaasv1-agent.log
    odk_ng service f5-oslbaasv1-agent restart
fi

