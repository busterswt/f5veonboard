#!/usr/bin/env python
"""Cluster BIG-IPs on OpenStack."""
import sys
import os.path
TOP_DIR = os.path.join(os.path.dirname(__file__), '../../../..')
TOP_DIR = os.path.abspath(TOP_DIR)
sys.path.insert(0, TOP_DIR)

import argparse
import datetime
import netaddr

from f5.bigip.bigip import BigIP


def mylog(msg):
    """Logger"""
    print '%s: %s' % (datetime.datetime.now().strftime('%b %d %H:%M:%S'), msg)


class BigIpFloatingSelfIPs(object):
    """BigIp Generic Clustering"""
    def __init__(self, bigip_config):
        self.bigip_config = bigip_config
        self.icontrol_bigips = []
        self.connected = False
        self.connected_by_access_addr = {}
        self.first_bigip = None

    def set_up(self):
        """Set up environment"""
        self.init_connections()
        mylog('adding floating SelfIPs')
        self._build_netmasks()
        self.add_floating_selfips()
        mylog('syncing config from device')
        self.sync_device_group_from_device()

    def init_connections(self):
        """Initialize connections to BIG-IPs"""
        if not self.connected:
            self.bigip = BigIP(self.bigip_config['host'],
                               self.bigip_config['username'],
                               self.bigip_config['password'],
                               timeout=5)
            mylog('Connected to ' + self.bigip_config['host'])
            self.connected = True

    def _build_netmasks(self):
        netmasks = [None] * len(self.bigip_config['selfip_list'])
        for i in range(0, len(self.bigip_config['selfip_list'])):
            ipaddr = netaddr.IPNetwork(
                addr=self.bigip_config['selfip_list'][i],
                implicit_prefix=True
            )
            netmasks[i] = str(ipaddr.netmask)
        self.bigip_config['netmask_list'] = netmasks

    def add_floating_selfips(self):
        """Create Floating SelfIPs"""
        for i in range(0, len(self.bigip_config['network_list'])):
            self.bigip.selfip.create(
                name="%s_floating_selfip" %
                     self.bigip_config['network_list'][i],
                ip_address=self.bigip_config['selfip_list'][i],
                netmask=self.bigip_config['netmask_list'][i],
                vlan_name=self.bigip_config['network_list'][i],
                floating=True,
                traffic_group='traffic-group-1',
                folder='Common',
                preserve_vlan_name=True)
            if self.bigip_config['access_list'][i] == 'default':
                self.bigip.selfip.set_port_lockdown_allow_default(
                    name="%s_floating_selfip" %
                         self.bigip_config['network_list'][i],
                    folder='/Common'
                )
            if self.bigip_config['access_list'][i] == 'all':
                self.bigip.selfip.set_port_lockdown_allow_all(
                    name="%s_floating_selfip" %
                         self.bigip_config['network_list'][i],
                    folder='/Common'
                )
            if self.bigip_config['access_list'][i] == 'none':
                self.bigip.selfip.set_port_lockdown_allow_none(
                    name="%s_floating_selfip" %
                         self.bigip_config['network_list'][i],
                    folder='/Common'
                )

    def sync_device_group_from_device(self):
        """Sync Device Service Group"""
        self.bigip.cluster.save_config()
        sync_devicegroup_name = self.bigip.device.get_device_group()
        self.bigip.cluster.sync(name=sync_devicegroup_name,
                                force_now=True)


def main(argv=None):
    if argv is None:
        argv = sys.argv
    # pylint: disable=broad-except
    # Okay to catch Exception at top level
    try:
        PARSER = argparse.ArgumentParser()
        PARSER.add_argument('--network-list',
                            nargs='+',
                            help='Ordered list of floating selfips networks',
                            required=True)
        PARSER.add_argument('--selfip-list',
                            nargs='+',
                            help='Ordered list of floating selfips',
                            required=True)
        PARSER.add_argument('--access-list',
                            nargs='+',
                            help='Ordered list of floating selfips access',
                            required=True)
        # Added implicitly defined attributes
        PARSER.add_argument(
            '--bigip-icontrol-host',
            metavar='bigip-icontrol-host',
            default='192.168.1.245',
            help='Host to use for iControl access.'
        )
        PARSER.add_argument(
            '--bigip-icontrol-username',
            metavar='bigip-icontrol-username',
            default='admin',
            help='Username to use for iControl access.'
        )
        PARSER.add_argument(
            '--bigip-icontrol-password',
            metavar='bigip-icontrol-password',
            default='admin',
            help='Password to use for iControl access.'
        )
        ARGS = PARSER.parse_args()

        BIGIP_CONFIG = {}
        BIGIP_CONFIG['host'] = ARGS.bigip_icontrol_host
        BIGIP_CONFIG['username'] = ARGS.bigip_icontrol_username
        BIGIP_CONFIG['password'] = ARGS.bigip_icontrol_password
        BIGIP_CONFIG['network_list'] = \
            ARGS.network_list
        BIGIP_CONFIG['selfip_list'] = \
            ARGS.selfip_list
        BIGIP_CONFIG['access'] = \
            ARGS.access_list

        BIGIP_FLOATING_SELFIPS = BigIpFloatingSelfIPs(
            BIGIP_CONFIG
        )
        BIGIP_FLOATING_SELFIPS.set_up()
    except Exception as exception:
        mylog('Exception: %s' % str(exception))
        import traceback
        traceback.print_exc()
        exit(1)
    exit(0)
    # pylint: enable=broad-except


if __name__ == "__main__":
    sys.exit(main())
