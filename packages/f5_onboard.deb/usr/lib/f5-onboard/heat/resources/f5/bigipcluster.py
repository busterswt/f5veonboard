""" F5 BIG-IP Cluster Resource """
import uuid
from oslo_log import log as logging
from heat.common.i18n import _
from heat.engine import constraints
from heat.engine import properties
from heat.engine import resource
from f5.onboard.bigip.cluster_generic import BigIpClusterGeneric

class LOG(object):
    """ Customized LOG replacement """
    @staticmethod
    def debug(logstr):
        """ debug log level """
        logf = open('/home/heatmanager/debug', 'a')
        logf.write(logstr)
        logf.write('\n')
        logf.close()

    @staticmethod
    def error(logstr):
        """ error log level """
        LOG.debug(logstr)

#LOG = logging.getLogger(__name__)

# this is how far down a nested stack we will search for resources
MAXDEPTH = 100

class BIGIPCluster(resource.Resource):
    """ F5 BIGIP Cluster """
    prefix = 'f5::bigipcluster: '

    PROPERTIES = (
        FLOATINGIP_RESOURCE_NAME, HA_TYPE, ADMIN_PASSWORD
    ) = (
        'floatingip_resource_name', 'ha_type', 'admin_password'
    )

    ATTRIBUTES = (
        FLOATINGIP_RESOURCE_NAME, HA_TYPE, ADMIN_PASSWORD,
        SHOW,
    ) = (
        'floatingip_resource_name', 'ha_type', 'admin_password',
        'show',
    )

    properties_schema = {
        FLOATINGIP_RESOURCE_NAME: properties.Schema(
            properties.Schema.STRING,
            _('Name of floating ip resources to use for mgmt of the bigips.'),
            default='bigip_mgmt_floatingip',
            update_allowed=False
        ),
        HA_TYPE: properties.Schema(
            properties.Schema.STRING,
            _('One of predefined ha types.'),
            required=True,
            constraints=[
                constraints.AllowedValues(['standalone', 'pair', 'scalen']),
            ]
        ),
        ADMIN_PASSWORD: properties.Schema(
            properties.Schema.STRING,
            _('Admin password to use for clustering setup.'),
            default='admin',
            update_allowed=False
        ),
    }

    @staticmethod
    def prepare_properties(props):
        props = dict((key, val) for key, val in props.items() \
            if val is not None)
        return props

    def handle_create(self, *args, **kwargs):
        LOG.debug(self.prefix + 'handle_create')
        if not self.resource_id:
            self.resource_id_set(str(uuid.uuid4()))
        props = self.prepare_properties(self.properties)
        LOG.debug(self.prefix + 'ha type: %s' % props['ha_type'])
        bigip_configs = self.get_bigip_configs()
        LOG.debug(self.prefix + 'bigip configs: %s' % bigip_configs)
        #LOG.debug(self.prefix + 'password: %s' % props['admin_password'])

    def check_create_complete(self, data):
        LOG.debug(self.prefix + 'check_create_completed')
        bigip_configs = self.get_bigip_configs()
        if bigip_configs:
            LOG.debug(self.prefix + 'bigip configs: %s' % bigip_configs)
            return True
        else:
            LOG.debug(self.prefix + 'geting bigip configs')
            return False

    def check_delete_complete(self, data):
        return True

    def get_bigip_configs(self):
        props = self.prepare_properties(self.properties)
        num_bigips = 0
        bigip_configs = []
        bigip_config = {}
        neutron_client = self.neutron()
        for res in self.stack.iter_resources(nested_depth=MAXDEPTH):
            if res.name == 'bigip_mgmt_port':
                LOG.debug("res %s" % res.name)
                if num_bigips > 0:
                    bigip_configs.append(bigip_config)
                num_bigips += 1
                bigip_config = {'name':'bigip' + str(num_bigips),
                                'password': props['admin_password']}
                if res.resource_id:
                    port = neutron_client.show_port(res.resource_id)
                    addr = port['port']['fixed_ips'][0]['ip_address']
                    bigip_config['mgmt_addr'] = addr
                    #LOG.debug("mgmt port id: %s" % res.resource_id)
                    #LOG.debug("mgmt port: %s" % port)
            elif res.name == 'bigip_mgmt_floatingip':
                LOG.debug("res %s" % res.name)

                floating_ip_out = res.stack.outputs['public_floating_ip']
                floating_ip = floating_ip_out.get('Value').result()
                if floating_ip:
                    floating_ip = str(floating_ip)
                    #LOG.debug(self.prefix + 'floating ip: %s' % floating_ip)
                    bigip_config['floating_ip_addr'] = floating_ip
            elif res.name == 'bigip_ha_self_port':
                LOG.debug("res %s" % res.name)
                if res.resource_id:
                    port = neutron_client.show_port(res.resource_id)
                    addr = port['port']['fixed_ips'][0]['ip_address']
                    bigip_config['ha_addr'] = addr
                    #LOG.debug("ha port id: %s" % res.resource_id)
                    #LOG.debug("ha port: %s" % port)
            elif res.name == 'bigip_mirroring_self_port':
                LOG.debug("res %s" % res.name)
                if res.resource_id:
                    port = neutron_client.show_port(res.resource_id)
                    addr = port['port']['fixed_ips'][0]['ip_address']
                    bigip_config['mirror_addr'] = addr
                    #LOG.debug("mirroring port id: %s" % res.resource_id)
                    #LOG.debug("mirroring port: %s" % port)
        if num_bigips > 0:
            bigip_configs.append(bigip_config)

        LOG.debug(self.prefix + 'gathering bigip configs: %s' % bigip_configs)

        num_complete_bigips = 0
        for config in bigip_configs:
            if 'floating_ip_addr' in config and \
                config['floating_ip_addr'] and \
                'mgmt_addr' in config and \
                config['mgmt_addr'] and \
                'ha_addr' in config and \
                config['ha_addr'] and \
                'mirror_addr' in config and \
                config['mirror_addr']:
                num_complete_bigips += 1

        if len(bigip_configs) and num_complete_bigips == len(bigip_configs):
            cluster = BigIpClusterGeneric(
                props['ha_type'],
                len(bigip_configs),
                bigip_configs,
            )
            cluster.set_up()
            return bigip_configs
        else:
            return []


def resource_mapping():
    return {
        'F5::BIGIP::Cluster': BIGIPCluster}
