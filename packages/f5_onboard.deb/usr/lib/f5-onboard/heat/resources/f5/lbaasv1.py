""" F5 BIG-IP Heat Resources
    Required rpms: openstack-neutron, openstack-neutron-lbaas
                   f5-oslbaasv1-agent
                   f5-bigip-common
    Requires a resource named bigip_mgmt_floatingip (for
    icontrol access) and bigip_vip_self_port (so this extension
    can allow the vip address using allowed_address_pairs)
    in the heat stack.
"""
import uuid
from heat.objects import stack as stack_object
from heat.engine.resources.openstack.neutron import loadbalancer
from oslo_log import log as logging
from neutron.plugins.common import constants as plugin_const

from oslo.config import cfg
from f5.oslbaasv1agent.drivers.bigip.icontrol_driver \
    import iControlDriver, OPTS as icontrol_OPTS

#class LOG(object):
#    """ Customized LOG replacement """
#    @staticmethod
#    def debug(logstr):
#        """ debug log level """
#        logf = open('/home/heatmanager/debug', 'a')
#        logf.write(logstr)
#        logf.write('\n')
#        logf.close()
#
#    @staticmethod
#    def error(logstr):
#        """ error log level """
#        LOG.debug(logstr)

LOG = logging.getLogger(__name__)

# this is how far down a nested stack we will search for lbaas resources
MAXDEPTH = 100

def _change_handler(self, delete=False, pool_resource=None):
    """ Process change to stack(s) (perhaps nested)
        and sync service to BIG-IP """
    if delete:
        status = plugin_const.PENDING_DELETE
    else:
        status = plugin_const.PENDING_CREATE

    LOG.debug(self.prefix + '  Props for current resource:')
    for key, val in self.properties.items():
        LOG.debug(self.prefix + '    %s: %s' % (key, val))

    services = {}
    pool_resources = {}
    if pool_resource:
        prop_dict = dict(pool_resource.properties.items())
        prop_dict['id'] = pool_resource.resource_id
        prop_dict['status'] = status
        prop_dict['tenant_id'] = pool_resource.stack.tenant_id
        services[pool_resource.resource_id] = {'pool':  prop_dict}
        pool_resources[pool_resource.resource_id] = pool_resource

    vip_addr = None
    root_stack = stack_object.Stack.load(self.stack.root_stack_id())
    for resource in root_stack.iter_resources(nested_depth=MAXDEPTH):
        if resource == pool_resource:
            continue
        if resource.has_interface('F5::LBaaSV1::Pool'):
            if not resource.resource_id:
                resource.resource_id_set(str(uuid.uuid4()))
            LOG.debug(self.prefix + '    found pool %s' % resource.resource_id)
            prop_dict = dict(resource.properties.items())
            prop_dict['id'] = resource.resource_id
            prop_dict['status'] = status
            prop_dict['tenant_id'] = resource.stack.tenant_id
            services[resource.resource_id] = {'pool':  prop_dict}
            metadata = resource.metadata_get()
            if metadata:
                services[resource.resource_id]['vip'] = metadata['vip']
                vip_addr = metadata['vip']['address']
            pool_resources[resource.resource_id] = resource
            #for key, val in resource.properties.items():
            #    LOG.debug(self.prefix + '        %s: %s' % (key, val))

    #LOG.debug(self.prefix + '  Stack (+nested) lbaas resources:')
    bigip_floating_ips = []
    for resource in root_stack.iter_resources(nested_depth=MAXDEPTH):
        show = False
        if resource.has_interface('F5::LBaaSV1::PoolMember'):
            if not resource.resource_id:
                resource.resource_id_set(str(uuid.uuid4()))
            LOG.debug(self.prefix + \
                '    found pool member %s' % resource.resource_id)
            for key, val in resource.properties.items():
                if key == 'pool_id':
                    LOG.debug(self.prefix + '    member for pool %s' % val)
                    if val not in services:
                        LOG.error(self.prefix + \
                            "Pool member for unknown pool %s" % val)
                        services[val] = {}
                    if 'members' not in services[val]:
                        services[val]['members'] = []
                    prop_dict = dict(resource.properties.items())
                    prop_dict['id'] = resource.resource_id
                    prop_dict['status'] = status
                    services[val]['members'].append(prop_dict)
            show = True
        elif resource.has_interface('F5::LBaaSV1::HealthMonitor'):
            if not resource.resource_id:
                resource.resource_id_set(str(uuid.uuid4()))
            #LOG.debug(self.prefix + \
            #    '    found health monitor %s' % resource.resource_id)
            for key, val in resource.properties.items():
                if key == 'pool_id':
                    if val not in services:
                        LOG.error("monitor for unknown pool %s" % val)
                        services[val] = {}
                    if 'monitors' not in services[val]:
                        services[val]['monitors'] = []
                    prop_dict = dict(resource.properties.items())
                    prop_dict['id'] = resource.resource_id
                    prop_dict['status'] = status
                    services[val]['monitors'].append(prop_dict)
            show = True
        elif resource.name == 'bigip_mgmt_floatingip':
            floating_ip_out = resource.stack.outputs['public_floating_ip']
            floating_ip = floating_ip_out.get('Value').result()
            floating_ip = str(floating_ip)
            #LOG.debug(self.prefix + 'floating ip: %s' % floating_ip)
            bigip_floating_ips.append(floating_ip)
            show = True
        elif resource.name == 'bigip_vip_self_port':
            if not delete and resource.resource_id and vip_addr:
                neutron_client = self.neutron()
                allowed_addresses = [{'ip_address':vip_addr}]
                port_update = {'allowed_address_pairs': allowed_addresses}
                port_update = {'port': port_update}
                #LOG.debug(self.prefix + \
                #    "Updating vip net self port: %s %s" % \
                #    (resource.resource_id, port_update))
                neutron_client.update_port(resource.resource_id, port_update)
                #LOG.debug(self.prefix + \
                #    "getting vip net self port: %s" % resource.resource_id)
                #updated_port = neutron_client.show_port(resource.resource_id)
                #LOG.debug(self.prefix + \
                #    "Updated vip net self port: %s" % updated_port)

        if show:
            #LOG.debug(self.prefix + \
            #    '    name: %s type: %s' % (resource.name, resource.type()))
            #for key, val in resource.properties.items():
            #    LOG.debug(self.prefix + '        %s: %s' % (key, val))
            pass

    for service_id, service in services.items():
        if not delete:
            metadata = pool_resources[service_id].metadata_get()
            if metadata:
                service['vip'] = metadata['vip']

    LOG.debug(self.prefix + '  services: %s' % services)

    # At this point we have service definitions that we can
    # apply to BIG-IP.

    if bigip_floating_ips:
        conf = cfg.CONF
        conf.register_opts(icontrol_OPTS)

        conf.icontrol_hostname = bigip_floating_ips[0]
        #LOG.debug("f5::lbaas using icontrol ip %s" % conf.icontrol_hostname)
        conf.use_namespaces = False
        conf.f5_global_routed_mode = True
        conf.icontrol_config_mode = 'iapp'
        conf.f5_ha_type = 'standalone'
        conf.environment_prefix = 'heat'

        try:
            driver = iControlDriver(conf, False)
            for key, service in services.items():
                LOG.debug(self.prefix + "sync: %s" % service)
                driver.sync(service)
        except:
            LOG.debug(self.prefix + 'icontrol failed')
            return False
        return True
    else:
        #LOG.debug(self.prefix + '  no bigip floating ip found')
        return False

class HealthMonitor(loadbalancer.HealthMonitor):
    """ F5 HealthMonitor """
    prefix = 'f5::hm: '

    _change_handler = _change_handler

    def handle_create(self, *args, **kwargs):
        LOG.debug(self.prefix + 'handle_create')
        try:
            self._change_handler()
        except Exception as exc:
            LOG.error(self.prefix + 'create error:' + str(exc))

    def check_create_complete(self, data):
        return True

    def _resolve_attribute(self, name):
        prop_dict = dict(self.properties.items())
        if name == 'show':
            return prop_dict
        else:
            return prop_dict[name]

    def handle_update(self, *args, **kwargs):
        #LOG.debug(self.prefix + 'handle_update')
        try:
            self._change_handler()
        except Exception as exc:
            LOG.error(self.prefix + 'update error:' + str(exc))

    def handle_delete(self, *args, **kwargs):
        #LOG.debug(self.prefix + 'handle_delete')
        try:
            self._change_handler()
        except Exception as exc:
            LOG.error(self.prefix + 'delete error:' + str(exc))

    def check_delete_complete(self, data):
        return True


class Pool(loadbalancer.Pool):
    """ F5 Pool """
    prefix = 'f5::pool: '

    _change_handler = _change_handler

    def handle_create(self, *args, **kwargs):
        #LOG.debug(self.prefix + 'handle_create')
        try:
            if not self.resource_id:
                self.resource_id_set(str(uuid.uuid4()))
            #LOG.debug(self.prefix + '    found pool %s' % self.resource_id)
            for key, val in self.properties.items():
                #LOG.debug(self.prefix + '        %s: %s' % (key, val))
                if key == 'vip':
                    neutron_client = self.neutron()
                    subnet = neutron_client.show_subnet(val['subnet'])
                    vip_net_id = subnet['subnet']['network_id']
                    vip_port = neutron_client.create_port(
                        {'port' : {'network_id':vip_net_id}})
                    vip_port = vip_port['port']
                    vip_addr = vip_port['fixed_ips'][0]['ip_address']
                    #LOG.debug(self.prefix + \
                    #    '        created vip addr %s port %s' % \
                    #    (vip_addr, vip_port['id']))
                    vip = {'id': self.resource_id, 'address': vip_addr,
                           'port_id': vip_port['id'],
                           'status': plugin_const.PENDING_CREATE}
                    self.metadata_set({'vip':vip})
            self._change_handler(self)
        except Exception as exc:
            LOG.error(self.prefix + 'create error:' + str(exc))

    def check_create_complete(self, data):
        return True

    def _resolve_attribute(self, name):
        self._change_handler()
        if name == self.VIP_ATTR:
            metadata = self.metadata_get()
            if metadata:
                return metadata['vip']
            else:
                return None
        else:
            prop_dict = dict(self.properties.items())
            if name == 'show':
                return prop_dict
            else:
                return prop_dict[name]

    def handle_update(self, *args, **kwargs):
        #LOG.debug(self.prefix + 'handle_update')
        try:
            self._change_handler()
        except Exception as exc:
            LOG.error(self.prefix + 'update error:' + str(exc))

    def handle_delete(self, *args, **kwargs):
        #LOG.debug(self.prefix + 'handle_delete')
        try:
            metadata = self.metadata_get()
            if metadata:
                vip_port_id = metadata['vip']['port_id']
                neutron_client = self.neutron()
                #LOG.debug(self.prefix + \
                #    '        deleting vip port %s' % vip_port_id)
                neutron_client.delete_port(vip_port_id)
                #LOG.debug(self.prefix + \
                #    '        deleted vip port %s' % vip_port_id)
            self._change_handler(delete=True)
        except Exception as exc:
            LOG.error(self.prefix + 'delete error:' + str(exc))
        return None

    def check_delete_complete(self, data):
        return True

class PoolMember(loadbalancer.PoolMember):
    """ F5 PoolMember """
    prefix = 'f5::poolmember: '

    _change_handler = _change_handler

    def handle_create(self, *args, **kwargs):
        #LOG.debug(self.prefix + 'handle_create')
        try:
            self._change_handler()
        except Exception as exc:
            LOG.error(self.prefix + 'create error:' + str(exc))

    def check_create_complete(self, data):
        completed = self._change_handler(self)
        #LOG.debug("pool member check_create_complete returning %s" % completed)
        return completed

    def _resolve_attribute(self, name):
        prop_dict = dict(self.properties.items())
        if name == 'show':
            return prop_dict
        else:
            return prop_dict[name]

    def handle_update(self, *args, **kwargs):
        #LOG.debug(self.prefix + 'handle_update')
        try:
            self._change_handler()
        except Exception as exc:
            LOG.error(self.prefix + 'update error:' + str(exc))

    def handle_delete(self, *args, **kwargs):
        LOG.debug(self.prefix + 'handle_delete')
        try:
            self._change_handler()
        except Exception as exc:
            LOG.error(self.prefix + 'delete error:' + str(exc))
        return None

    def check_delete_complete(self, data):
        return True

def resource_mapping():
    return {
        'F5::LBaaSV1::HealthMonitor': HealthMonitor,
        'F5::LBaaSV1::Pool': Pool,
        'F5::LBaaSV1::PoolMember': PoolMember}
