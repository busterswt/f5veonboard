#!/bin/bash
HEAT_DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && cd .. && pwd )
source $HEAT_DIR/utils/heat-utils.sh

if [ -z "$1" -o -z "$2" ]; then
    echo "usage  : $0 <template_name> <app_name> [optional custom defaults file]"
    echo "example: $0 wordpress my_wordpress wordpress-defaults-hpcloud.yaml"
    exit 1
else
    TEMPLATE_NAME=$1
    APP_NAME=$2
fi

if [ -z "$3" ]; then
    DEFAULTS_FILE=heat/templates/${TEMPLATE_NAME}/${TEMPLATE_NAME}-defaults.yaml
else
    DEFAULTS_FILE=heat/templates/${TEMPLATE_NAME}/$3
fi

check_openstack_vars
heat_standalone_env

# create or update heat templates on heat server
$HEAT_UTILS_DIR/deploy-heat-templates.sh

# Create app using standalone heat server
set -x
$HEAT_SSH heat $HEAT_AUTH_OPTS stack-create \
    -f heat/templates/${TEMPLATE_NAME}/${TEMPLATE_NAME}.yaml \
    -e $DEFAULTS_FILE \
    ${APP_NAME}
set +x
echo To view this stack, run:
echo $HEAT_UTILS_DIR/show-app.sh $APP_NAME
echo To destroy this stack, run:
echo $HEAT_UTILS_DIR/destroy-app.sh $APP_NAME

