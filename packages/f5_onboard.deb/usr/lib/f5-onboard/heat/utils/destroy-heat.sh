#!/bin/bash
HEAT_DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && cd .. && pwd )
source $HEAT_DIR/utils/heat-utils.sh

check_openstack_vars

TENANT_ID=$(python $HEAT_UTILS_DIR/get_tenant_id.py)
if [ -z "$TENANT_ID" ]; then
    echo $0: could not get tenant id!
    exit 1
fi
HEAT_AUTH_OPTS="--os-tenant-id $TENANT_ID"

APP_NAME=heat_server
echo heat $HEAT_AUTH_OPTS stack-list
stacks=$(heat $HEAT_AUTH_OPTS stack-list | grep -e " ${APP_NAME} " -e " ${APP_NAME}-" | cut -d' ' -f2)
until [ -z "$stacks" ]; do
    echo Stacks left:
    echo $stacks
    for stack in $stacks; do
        echo 'heat $HEAT_AUTH_OPTS stack-delete' $stack
        heat $HEAT_AUTH_OPTS stack-delete $stack
    done
    echo sleep 10
    sleep 10
    stacks=$($HEAT_SSH heat $HEAT_AUTH_OPTS stack-list | grep -e " ${APP_NAME} " -e " ${APP_NAME}-" | cut -d' ' -f2)
done

