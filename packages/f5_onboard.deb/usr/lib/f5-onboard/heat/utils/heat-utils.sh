function check_openstack_vars {
    if [ -z "$OS_AUTH_URL" ]; then
        echo "you must set OS_AUTH_URL"
        exit 1
    fi
    if [ -z "$OS_TENANT_NAME" ]; then
        echo "you must set OS_TENANT_NAME"
        exit 1
    fi
    if [ -z "$OS_USERNAME" ]; then
        echo "you must set OS_USERNAME"
        exit 1
    fi
    if [ -z "$OS_PASSWORD" ]; then
        echo "you must set OS_PASSWORD"
        exit 1
    fi
}

function heat_standalone_env {
    # Set variables and keys for accessing standalone heat server
    TENANT_ID=$(python $HEAT_UTILS_DIR/get_tenant_id.py)
    if [ -z "$TENANT_ID" ]; then
        echo "could not get tenant id!"
        exit 1
    fi
    TENANT_CREDS="--os-tenant-id $TENANT_ID --os-username $OS_USERNAME --os-password $OS_PASSWORD"

    HEAT_AUTH_OPTS=$(heat $TENANT_CREDS output-show heat_server private_heat_auth_opts | sed s/\"//g)
    export HEAT_AUTH_OPTS="$TENANT_CREDS $HEAT_AUTH_OPTS"
    export HEAT_SERVER_IP=$(heat $TENANT_CREDS output-show heat_server public_floating_ip | sed s/\"//g)

    HEAT_TMP_DIR=~/.heatstandalone/tenants/$TENANT_ID
    mkdir -p $HEAT_TMP_DIR
    HEAT_KEY_FILE=$HEAT_TMP_DIR/heat_server.key
    HEAT_KEY=$(heat $TENANT_CREDS output-show heat_server server_key)
    echo -e $HEAT_KEY | sed 's/\"//g' > $HEAT_KEY_FILE
    chmod 600 $HEAT_KEY_FILE

    HEAT_SSH_OPTS="-o StrictHostKeyChecking=no -o LogLevel=quiet -i $HEAT_KEY_FILE"
    export HEAT_SSH="ssh $HEAT_SSH_OPTS centos@$HEAT_SERVER_IP"
    export HEAT_SCP="scp $HEAT_SSH_OPTS"
}
function get_heat_output {
    $HEAT_SSH heat $TENANT_CREDS $HEAT_AUTH_OPTS output-show $1 $2 2> /dev/null | sed s/\"//g
}
function get_local_heat_output {
    heat output-show $1 $2 2> /dev/null | sed s/\"//g
}

HEAT_TOP_DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && cd .. && pwd )
HEAT_UTILS_DIR=$HEAT_TOP_DIR/utils
HEAT_TEMPLATES_DIR=$HEAT_TOP_DIR/templates
