#!/bin/bash
HEAT_DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && cd .. && pwd )
source $HEAT_DIR/utils/heat-utils.sh

if [ -z "$1" ]; then
    echo "usage  : destroy-app.sh <app_name>"
    echo "example: destroy-app.sh my_wordpress"
    exit 1
else
    APP_NAME=$1
fi

check_openstack_vars
heat_standalone_env

# Use tenant auth and standalone heat endpoint options to delete app
stacks=$($HEAT_SSH heat $HEAT_AUTH_OPTS stack-list --show-nested | grep -e " ${APP_NAME} " -e " ${APP_NAME}-" | cut -d' ' -f2)
until [ -z "$stacks" ]; do
    echo Stacks left:
    echo $stacks
    for stack in $stacks; do
        echo '$HEAT_SSH heat $HEAT_AUTH_OPTS stack-delete' $stack
        $HEAT_SSH heat $HEAT_AUTH_OPTS stack-delete $stack
    done
    echo sleep 10
    sleep 10
    stacks=$($HEAT_SSH heat $HEAT_AUTH_OPTS stack-list --show-nested | grep -e " ${APP_NAME} " -e " ${APP_NAME}-" | cut -d' ' -f2)
done
