#!/bin/bash
HEAT_DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && cd .. && pwd )
source $HEAT_DIR/utils/heat-utils.sh

TEMPLATE_NAME=heat_server

if [ -z "$1" ]; then
    DEFAULTS_FILE=$HEAT_TEMPLATES_DIR/$TEMPLATE_NAME/${TEMPLATE_NAME}-defaults.yaml
else
    DEFAULTS_FILE=$1
fi
if [ ! -e "$DEFAULTS_FILE" ]; then
   echo "file $DEFAULTS_FILE not found"
   exit 1
fi

check_openstack_vars

KEYSTONE_IP=`echo $OS_AUTH_URL | sed 's#http[s]*://\([^:]*\):.*#\1#'`
KEYSTONE_PROTO=`echo $OS_AUTH_URL | sed 's#\(http[s]*\)://[^:]*:.*#\1#'`
TENANT_ID=$(python $HEAT_UTILS_DIR/get_tenant_id.py)
if [ -z "$TENANT_ID" ]; then
    echo $0: could not get tenant id!
    exit 1
fi
TENANT_CREDS="--os-tenant-id $TENANT_ID"

# Create heat server
set -x
heat $TENANT_CREDS stack-create \
    -f $HEAT_TEMPLATES_DIR/$TEMPLATE_NAME/${TEMPLATE_NAME}.yaml \
    -e $DEFAULTS_FILE \
    -P keystone_ip=$KEYSTONE_IP \
    -P keystone_proto=$KEYSTONE_PROTO \
    -P project_id=$TENANT_ID \
    heat_server
date
sleep 600
set +x

heat_standalone_env

until $HEAT_SSH heat $HEAT_AUTH_OPTS stack-list
do
    echo waiting 30 more seconds until heat server is ready
    sleep 30
done

# Install F5 Templates into heat
$HEAT_UTILS_DIR/deploy-heat-templates.sh
echo To view details of the standalone heat server, run:
echo $HEAT_UTILS_DIR/show-heat.sh
echo To destroy the standalone heat server, run:
echo $HEAT_UTILS_DIR/destroy-heat.sh
echo Be sure to destroy any stacks owned by the heat server first.

