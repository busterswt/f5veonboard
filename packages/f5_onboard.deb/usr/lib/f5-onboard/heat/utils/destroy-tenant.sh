#!/bin/bash
HEAT_TOP_DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && cd .. && pwd )
source $HEAT_TOP_DIR/utils/heat-utils.sh

if [ -z "$1" ]; then
    echo "usage  : destroy-tenant <tenant_name>"
    echo "example: destroy-tenant.sh tenant1"
    exit 1
else
    TENANT=$1
fi

check_openstack_vars

if [ "$OS_TENANT_NAME" != "admin" ]; then
    echo "OS_TENANT_NAME must be admin"
    exit 1
fi
if [ "$OS_USERNAME" != "admin" ]; then
    echo "OS_USERNAME must be admin"
    exit 1
fi

TENANT_ID=$(keystone tenant-get $TENANT | grep ' id ' | cut -d'|' -f3 | sed 's/^ *//g' | sed 's/ *$//g')
if [ -n "$TENANT_ID" ]; then
    set -x
    keystone user-delete ${TENANT}_manager
    keystone tenant-delete $TENANT
    set +x
fi
