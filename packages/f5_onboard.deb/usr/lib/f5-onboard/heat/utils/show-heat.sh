#!/bin/bash
HEAT_DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && cd .. && pwd )
source $HEAT_DIR/utils/heat-utils.sh

check_openstack_vars

TENANT_ID=$(python $HEAT_UTILS_DIR/get_tenant_id.py)
if [ -z "$TENANT_ID" ]; then
    echo could not get tenant id!
    exit 1
fi
TENANT_CREDS="--os-tenant-id $TENANT_ID"
heat $TENANT_CREDS stack-show heat_server
heat $TENANT_CREDS stack-list
heat $TENANT_CREDS resource-list heat_server
HEAT_SERVER_IP=$(get_local_heat_output heat_server public_floating_ip)
PUBLIC_HEAT_AUTH_OPTS=$(get_local_heat_output heat_server public_heat_auth_opts)
PRIVATE_HEAT_AUTH_OPTS=$(get_local_heat_output heat_server private_heat_auth_opts)
echo Heat server ip: $HEAT_SERVER_IP
echo Public Heat auth opts: $PUBLIC_HEAT_AUTH_OPTS
echo Private Heat auth opts: $PRIVATE_HEAT_AUTH_OPTS

heat_standalone_env
echo $HEAT_SSH heat $HEAT_AUTH_OPTS stack-list
