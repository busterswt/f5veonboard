#!/bin/bash
HEAT_DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && cd .. && pwd )
source $HEAT_DIR/utils/heat-utils.sh

if [ -z "$1" ]; then
    echo "usage  : show-app <app_name>"
    echo "example: show-app.sh my_wordpress"
    exit 1
else
    APP_NAME=$1
fi

check_openstack_vars
heat_standalone_env

$HEAT_SSH heat $HEAT_AUTH_OPTS stack-list --show-nested
stacks=$($HEAT_SSH heat $HEAT_AUTH_OPTS stack-list --show-nested | grep -e " ${APP_NAME} " -e " ${APP_NAME}-" | cut -d' ' -f2)
for stack in $stacks; do
  echo Stack: $stack
  $HEAT_SSH heat $HEAT_AUTH_OPTS stack-show $stack
  $HEAT_SSH heat $HEAT_AUTH_OPTS resource-list $stack
done
echo "Here is an example command if you want to check further detailed status manually:"
echo $HEAT_SSH heat $HEAT_AUTH_OPTS stack-list --show-nested 
