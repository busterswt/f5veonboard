#!/bin/bash
HEAT_TOP_DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && cd .. && pwd )
source $HEAT_TOP_DIR/utils/heat-utils.sh

if [ -z "$1" ]; then
    echo "This script creates a new tenant with a user "
    echo "with the name <tenant-name>_manager and password: default"
    echo "usage  : $0 <tenant-to-create>"
    echo "example: $0 tenant1"
    echo "The example would create tenant named tenant1"
    echo "with a user named tenant1_manager and password default"
    exit 1
else
    TENANT=$1
fi

check_openstack_vars

if [ "$OS_TENANT_NAME" != "admin" ]; then
    echo "OS_TENANT_NAME must be admin"
    exit 1
fi
if [ "$OS_USERNAME" != "admin" ]; then
    echo "OS_USERNAME must be admin"
    exit 1
fi

#
# Create tenant if necessary using admin creds
#
TENANT_ID=$(keystone tenant-get $TENANT 2> /dev/null | grep ' id ' | cut -d'|' -f3 | sed 's/^ *//g' | sed 's/ *$//g')
if [ -z "$TENANT_ID" ]; then
    keystone tenant-create --name $TENANT
    keystone user-create --name ${TENANT}_manager \
                         --tenant $TENANT \
                         --pass default
fi
