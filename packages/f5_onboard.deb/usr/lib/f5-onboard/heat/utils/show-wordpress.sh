#!/bin/bash
HEAT_DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && cd .. && pwd )
source $HEAT_DIR/utils/heat-utils.sh

check_openstack_vars

APP_NAME=$1

$HEAT_UTILS_DIR/show-app.sh $APP_NAME

heat_standalone_env

echo
echo "Wordpress specific info: "
bigip_pattern="${APP_NAME}-lb_base-............-bigip_cluster-............-bigips-............-"
bigip_stacks=$($HEAT_SSH heat $HEAT_AUTH_OPTS stack-list --show-nested | grep -v None | grep CREATE | grep -e "$bigip_pattern" | cut -d' ' -f2)
for bigip_stack in $bigip_stacks; do
  echo "bigip stack: $bigip_stack"
  echo "    floating ip: `get_heat_output $bigip_stack public_floating_ip`"
  echo "    floating ip id: `get_heat_output $bigip_stack public_floating_ip_id`"
  echo "    license: `get_heat_output $bigip_stack f5_license_key`"
done

echo "$APP_NAME floating ip: `get_heat_output $APP_NAME public_floating_ip`"
echo "$APP_NAME website_url: `get_heat_output $APP_NAME website_url`"
