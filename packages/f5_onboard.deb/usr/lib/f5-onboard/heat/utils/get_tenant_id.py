import json
import os
import requests
import sys
from keystoneclient.v2_0 import client
from keystoneclient.v2_0 import tokens

auth_url=os.environ['OS_AUTH_URL']
tenant_name=os.environ['OS_TENANT_NAME']
username=os.environ['OS_USERNAME']
password=os.environ['OS_PASSWORD']
keystone = client.Client(username=username, password=password, tenant_name=tenant_name, auth_url=auth_url)
#keystone = client.Client(username=username, password=password, auth_url=auth_url)
token = keystone.auth_token
headers = {'X-Auth-Token': token }
tenant_url = auth_url
tenant_url += '/tenants'
r = requests.get(tenant_url, headers=headers)
for tenant in r.json()['tenants']:
   if tenant["name"] == tenant_name:
       print tenant['id']
       sys.exit(0)
sys.exit(1)
