#!/bin/bash
HEAT_DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && cd .. && pwd )
source $HEAT_DIR/utils/heat-utils.sh

check_openstack_vars
heat_standalone_env

# Install F5 Templates into heat
mkdir -p ~/.f5-onboard/tmp
(cd $HEAT_DIR/..;tar cvzpf ~/.f5-onboard/tmp/heat.tgz heat)
$HEAT_SCP ~/.f5-onboard/tmp/heat.tgz centos@$HEAT_SERVER_IP:
$HEAT_SSH tar xvzpf heat.tgz
