#!/bin/bash

if [ -z "$1" ]; then
    echo "usage  : show-tenant.sh <tenant>"
    echo "example: show-tenant.sh tenant1"
    exit 1
else
    TENANT=$1
fi

set -x
keystone tenant-get $TENANT
keystone user-get ${TENANT}_manager
set +x


