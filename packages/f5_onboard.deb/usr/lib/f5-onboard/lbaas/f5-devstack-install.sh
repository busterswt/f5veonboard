#!/bin/bash
source odk-utils

# NOVA fixup
sudo echo -e "[Nova]\\nvendor = Red Hat\\nproduct = Bochs\\npackage = RHEL 6.3.0 PC\\n"  > /etc/nova/release

proj=neutron
plugin=f5-bigip-lbaas-agent
[ ! -d /var/run/$proj ] && (sudo mkdir -p /var/run/$proj;sudo chmod ugo+wx /var/run/$proj)


cd /opt/stack/neutron
tar xvzf /tmp/f5-lbaas-devstack.tgz
sudo mv etc/f5-bigip-lbaas-agent.ini /etc/neutron
NEUTRON_CONF=/etc/neutron/neutron.conf
F5_INI=/etc/neutron/f5-bigip-lbaas-agent.ini

sudo sed -i 's/^service_plugins\ =\ neutron.services.l3_router.l3_router_plugin.L3RouterPlugin/service_plugins\ =neutron.services.l3_router.l3_router_plugin.L3RouterPlugin,neutron.services.loadbalancer.plugin.LoadBalancerPlugin/' $NEUTRON_CONF

sudo sed -i 's/service_provider=LOADBALANCER:Haproxy:neutron.services.loadbalancer.drivers.haproxy.plugin_driver.HaproxyOnHostPluginDriver:default/service_provider=LOADBALANCER:f5:neutron.services.loadbalancer.drivers.f5.plugin_driver.F5PluginDriver:default/' $NEUTRON_CONF
sudo sed -i 's/^# debug.*/debug\ =\ True/' $NEUTRON_CONF
sudo sed -i 's/f5_vtep_selfip_name\ =\ vtep/f5_vtep_selfip_name\ =\ selfip.datanet/' $F5_INI

mkdir -p /opt/stack/neutron/log

