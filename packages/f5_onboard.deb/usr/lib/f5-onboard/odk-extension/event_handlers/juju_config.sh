
source f5-onboard-utils

if [ $NETWORK_TYPE = "vlan" ]; then
    if [ $DISTRO = 'precise' ]; then
        bigip_port=`f5-onboard-get-conf singletons globals BIGIP_PORT_PRECISE`
    else
        bigip_port=`f5-onboard-get-conf singletons globals BIGIP_PORT`
    fi
    if [ -n "$bigip_port" ]; then
      bridge_ports=`cat $JUJU_CONFIG | grep ovs-bridge-ports | head -1 | \
                       sed 's/\s*ovs-bridge-ports:\s*"\([^"]*\)"/\1/'`
      if [ -z "$bridge_ports" ]; then
          bridge_ports="br-bigips:$bigip_port"
      else
          bridge_ports="$bridge_ports,br-bigips:$bigip_port"
      fi
      sed -i -e"s/\(\s*ovs-bridge-ports:\s*\).*/\1\"$bridge_ports\"/" $JUJU_CONFIG
    fi
fi


