#
# The normal hierarchy of loops is this:
# deploy_test_all calls
#   deploy_test_all_by_machine_count calls
#     deploy_test_all_for_distro calls
#       deploy_test_all_for_openstack_release calls
#         deploy_test_all_for_neutron_plugin sets haproxy and calls
#           deploy_test_all_for_lbaas_driver
#             deploy_test_all_for_network_type calls
#               deploy_test_current_variation calls:
#                 set_variation
#                 show_variation
#                 deploy_openstack
#                 deploy_admin_base
#                 test_openstack
# 
# Note that the *only* thing that deploy_test_all_for_network_type
# does is call deploy_test_current_variation.
# Basically, it is saying, "All variables are set! Run the test!".
# This extension changes that. It overrides that function in order
# to loop through BIG-IP versions and test those.
# This extension also overrides deploy_test_all_for_neutron_plugin
# in order to test more lbaas driver types.
#
# deploy_test_all calls
#   deploy_test_all_by_machine_count calls
#     deploy_test_all_for_distro calls
#       deploy_test_all_for_openstack_release calls
#         deploy_test_all_for_neutron_plugin which
# *new:     loops through each lbaas type (f5, haproxy, and combos) and calls
#             deploy_test_all_for_lbaas_driver calls
#               deploy_test_all_for_network_type calls
#                  deploy_test_all_for_icontrol_config_modes
#                    deploy_test_all_for_service_manager_type
#                     deploy_test_all_for_bigiq_images
#                      deploy_test_all_for_bigip_type
#                       deploy_test_all_for_bigip_image calls
#                         deploy_openstack
#                         deploy_admin_base which
#                         loops through each HA_TYPE type which
#                           loops through each plugin replication mode and calls:
#                             set_variation
#                             show_variation
#                             if service_manager = "bigiq"
#                               f5-onboard-ve-odk deploy-admin-bigiqs-base
#                               f5-onboard-ve-odk deploy-admin-bigiqs
#                             if bigip_type = "onboard-ve"
#                               f5-onboard-ve-odk deploy-admin-bigips-base
#                               f5-onboard-ve-odk deploy-admin-bigips
#                             test_openstack
#                             if bigip_type = "onboard-ve"
#                               f5-onboard-ve-odk destroy-admin-bigips
#                               f5-onboard-ve-odk destroy-admin-bigips-base
#                             if service_manager = "bigiq"
#                               f5-onboard-ve-odk destroy-admin-bigiqs
#                               f5-onboard-ve-odk destroy-admin-bigiqs-base

source f5-onboard-utils

odk-set-conf singletons globals test_lb=true
odk-set-conf singletons globals test_shared_lb=true

function deploy_test_all_lb_drivers {
    for LBAAS_DRIVER in f5 f5,haproxy
    do
        # if user specified --lbaas-driver then skip others
        if [ -n "$ARG_LBAAS_DRIVER" -a \
                "$LBAAS_DRIVER" != "$ARG_LBAAS_DRIVER" ]; then
          continue
        fi
        ENABLE_SHARED_NET_LBAAS_TESTS="--test-shared-lb"
        deploy_test_all_for_lbaas_driver
    done

    for LBAAS_DRIVER in haproxy haproxy,f5
    do
        # if user specified --lbaas-driver then skip others
        if [ -n "$ARG_LBAAS_DRIVER" -a \
                "$LBAAS_DRIVER" != "$ARG_LBAAS_DRIVER" ]; then
          continue
        fi
        ENABLE_SHARED_NET_LBAAS_TESTS=""
        deploy_test_all_for_lbaas_driver
    done
}

function set_variation {
    variation="$OPENSTACK_RELEASE on $DISTRO"
    variation="$variation\\nwith $NEUTRON_PLUGIN plugin"
    variation="$variation\\nnetwork type $NETWORK_TYPE"
    variation="$variation\\nlbaas $LBAAS_DRIVER"
    variation="$variation\\nBIG-IP type $BIGIP_TYPE"
    variation="$variation\\nservice manager type $SERVICE_MANAGER"
    variation="$variation\\nicontrol config mode $ICONTROL_CONFIG_MODE"
}

# This overrides the default function in order to
# test f5 specific variations.
function deploy_test_all_for_network_type {
    if [ "$LBAAS_DRIVER" = "haproxy" ]; then
        deploy_test_current_variation
        return
    fi

    deploy_test_all_for_icontrol_config_modes
}

function deploy_test_all_for_icontrol_config_modes {
    for ICONTROL_CONFIG_MODE in iapp object
    do
        if [ -n "$ARG_ICONTROL_CONFIG_MODE" -a \
                "$ICONTROL_CONFIG_MODE" != "$ARG_ICONTROL_CONFIG_MODE" ]; then
            continue
        fi

        deploy_test_all_for_service_manager_type
    done
}

function deploy_test_all_for_service_manager_type {
    for SERVICE_MANAGER in none bigiq
    do
        if [ -n "$ARG_SERVICE_MANAGER" -a \
                "$SERVICE_MANAGER" != "$ARG_SERVICE_MANAGER" ]; then
            continue
        fi

        f5-onboard-set-state deployments odk-maas SERVICE_MANAGER=$SERVICE_MANAGER

        if [ "$SERVICE_MANAGER" = "none" ]; then
            deploy_test_all_for_bigip_type
        elif [ "$SERVICE_MANAGER" = "bigiq" ]; then 
            deploy_test_all_for_bigiq_images
        else
            echo "Unrecognized service manager $SERVICE_MANAGER"
            exit 1
        fi
    done
}

function deploy_test_all_for_bigiq_images {
    BIGIQ_IMAGES="BIG-IQ-4.5.0.0.0.7028-OpenStack.qcow2"

    for BIGIQ_IMAGE in $BIGIQ_IMAGES
    do
        # if user specified --bigiq-image then skip others
        if [ -n "$ARG_BIGIQ_IMAGE" -a \
                "$BIGIQ_IMAGE" != "$ARG_BIGIQ_IMAGE" ]; then
            continue
        fi

        # only standalone is supported for initial implementation
        for BIGIQ_HA_TYPE in standalone #pair scalen
        do
            if [ -n "$ARG_BIGIQ_HA_TYPE" -a \
                    "$HA_BIGIQ_TYPE" != "$ARG_BIGIQ_HA_TYPE" ]; then
                continue
            fi

          # strictly speaking, BIG-IQ would be deployed prior to making the 
          # call to deploy the BIG-IP(s).  However, since BIG-IQ is VE and 
          # runs in OpenStack and the OpenStack lifecycle is bound to BIG-IP
          # deployment, BIG-IQ deployment is deferred until BIG-IP deployment.
          deploy_test_all_for_bigip_type
          destroy_service_manager
        done
    done
}

function deploy_service_manager {
    if [ "$SERVICE_MANAGER" = "none" ]; then
        f5-onboard-set-state clusters admin1 NUM_BIGIQS=0
        f5-onboard-set-state clusters admin1 BIGIQ_MGMT_IPS=
        return
    fi

    if [ "$SERVICE_MANAGER" = "bigiq" ]; then 
        deploy_service_manager_bigiq
        return
    fi

    echo "Unrecognized service manager $SERVICE_MANAGER"
    exit 1
}

function destroy_service_manager {
    if [ "$SERVICE_MANAGER" = "none" ]; then
        return
    fi

    if [ "$SERVICE_MANAGER" = "bigiq" ]; then 
        destroy_service_manager_bigiq
        return
    fi

    echo "Unrecognized service manager $SERVICE_MANAGER"
    exit 1
}


function deploy_service_manager_bigiq {
    set -x
    f5-onboard-ve-odk deploy-admin-bigiqs-base \
        --bigiq-image $BIGIQ_IMAGE \
        | tee -a $DETAIL_LOG
    testresult=${PIPESTATUS[0]}
    set +x
    if [ $testresult -ne 0 ]; then
        echo -e "`date` Deploy BIG-IQs Base Failed for $variation" \
              | tee -a $SUMMARY_LOG
        exit $testresult
    fi

    set -x
    f5-onboard-ve-odk deploy-admin-bigiqs \
                                     --bigiq-image $BIGIQ_IMAGE \
                                     --ha-type $BIGIQ_HA_TYPE \
                                         | tee -a $DETAIL_LOG
    testresult=${PIPESTATUS[0]}
    set +x
    if [ $testresult -ne 0 ]; then
        echo -e "`date` Deploy BIG-IQs Failed for $variation" \
              | tee -a $SUMMARY_LOG
        exit $testresult
    fi
}

function destroy_service_manager_bigiq {
    local NUM_BIGIQS=`f5-onboard-get-state clusters admin1 NUM_BIGIQS`

    if [ -z "$NUM_BIGIQS" -o "$NUM_BIGIQS" = "0" ]; then
        echo "No BIG-IQs deployed."
        return
    fi

    set -x
    f5-onboard-ve-odk destroy-admin-bigiqs \
                                         | tee -a $DETAIL_LOG
    testresult=${PIPESTATUS[0]}
    set +x
    if [ $testresult -ne 0 ]; then
        echo -e "`date` Deploy BIG-IQs Failed for $variation" \
              | tee -a $SUMMARY_LOG
        exit $testresult
    fi

    set -x
    f5-onboard-ve-odk destroy-admin-bigiqs-base \
                                     --bigiq-image $BIGIQ_IMAGE \
                                         | tee -a $DETAIL_LOG
    testresult=${PIPESTATUS[0]}
    set +x
    if [ $testresult -ne 0 ]; then
        echo -e "`date` Deploy BIG-IQs Base Failed for $variation" \
              | tee -a $SUMMARY_LOG
        exit $testresult
    fi

    echo "`date` Sleeping 60 seconds before next bigiq variation."
    echo "`date` TO ABORT FOR MANUAL TROUBLESHOOTING USE CTRL C NOW"
    sleep 60
}

function deploy_test_all_for_bigip_type {
    for BIGIP_TYPE in onboard-ve static static-vcmp
    do
        if [ -n "$ARG_BIGIP_TYPE" -a \
                "$BIGIP_TYPE" != "$ARG_BIGIP_TYPE" ]; then
            continue
        fi

        if [ "$BIGIP_TYPE" = "static" ]; then 
            local STATIC_CLUSTER_NAME=`f5-onboard-get-conf deployments odk-maas STATIC_CLUSTER_NAME`

            # if user specified static, there should be a static cluster declared
            if [ -z "$STATIC_CLUSTER_NAME" -a \
                    "$ARG_BIGIP_TYPE" = "static" ]; then
                echo "Cannot test static cluster unless you do:"
                echo "f5-onboard-set-conf deployments odk-maas STATIC_CLUSTER_NAME=<static-cluster-state-def>"
                echo "See documentation."
                exit 1
            fi
            
            # only run the static test if the static cluster is declared
            if [ -n "$STATIC_CLUSTER_NAME" ]; then
                f5-onboard-set-state deployments odk-maas CLUSTER_NAME=$STATIC_CLUSTER_NAME

                deploy_test_all_for_static_f5_onboard
            fi
        elif [ "$BIGIP_TYPE" = "static-vcmp" ]; then
            local STATIC_VCMP_CLUSTER_NAME=`f5-onboard-get-conf deployments odk-maas STATIC_VCMP_CLUSTER_NAME`

            # if user specified static-vcmp, there should be a static vcmp cluster declared
            if [ -z "$STATIC_VCMP_CLUSTER_NAME" -a \
                    "$ARG_BIGIP_TYPE" = "static-vcmp" ]; then
                echo "Cannot test static vCMP cluster unless you do:"
                echo "f5-onboard-set-conf deployments odk-maas STATIC_VCMP_CLUSTER_NAME=<static-vcmp-cluster-state-def>"
                echo "See documentation."
                exit 1
            fi
            
            # only run the static vcmp test if the static vcmp cluster is declared
            if [ -n "$STATIC_VCMP_CLUSTER_NAME" ]; then
                f5-onboard-set-state deployments odk-maas CLUSTER_NAME=$STATIC_VCMP_CLUSTER_NAME

                deploy_test_all_for_static_f5_onboard
            fi
        else
            # auto-f5-onboard
            if [ "$NETWORK_TYPE" = "vlan" ]; then
                if [ $DISTRO = 'precise' ]; then
                    bigip_port=`f5-onboard-get-conf singletons globals BIGIP_PORT_PRECISE`
                else
                    bigip_port=`f5-onboard-get-conf singletons globals BIGIP_PORT`
                fi
                if [ -z "$bigip_port" ]; then
                    echo "Cannot test VLANs with VE unless you do:"
                    echo "f5-onboard-set-conf singletons globals BIGIP_PORT=p1p2"
                    echo "f5-onboard-set-conf singletons globals BIGIP_PORT_PRECISE=eth4"
                    echo "See documentation."
                    return
                fi
            fi

            deploy_test_all_for_bigip_images
        fi
    done
}

function deploy_test_all_for_static_f5_onboard {
    set_variation
    show_variation
    if [ -z "$NO_DEPLOY" ]; then
        deploy_openstack
    fi
    check_openstack
    # NO_DEPLOY really only makes sense for the first iteration
    # when openstack may already be deployed. Once we proceed
    # onto further test iterations, it makes sense to deploy again.
    # So we reset the variable here in order to ensure that happens.
    NO_DEPLOY=""
    deploy_admin_base
    deploy_service_manager
    if [ $LBAAS_DRIVER = "f5" -o $LBAAS_DRIVER = "f5,haproxy" ]; then
        odkcmd f5-onboard-lbaas unconfig-bigip-plugin
        odkcmd f5-onboard-lbaas config-bigip-plugin
    fi
    if [ -n "$ARG_TEST" ]; then
        test_openstack
    fi
    # If --all not specifed then exit after one variation
    if [ -z "$ARG_ALL" ]; then
        exit 0
    fi
}

function deploy_test_all_for_bigip_images {
    BIGIP_IMAGES="BIGIP-12.0.0.0.0.606-OpenStack.qcow2"
    BIGIP_IMAGES="$BIGIP_IMAGES BIGIP-11.5.3.0.0.163-OpenStack.qcow2"
    BIGIP_IMAGES="$BIGIP_IMAGES BIGIP-11.5.2.0.0.141-OpenStack.qcow2"
    BIGIP_IMAGES="$BIGIP_IMAGES BIGIP-11.6.0.0.0.401-HF-4.0.420-OpenStack.qcow2"
    if [ $NETWORK_TYPE = "vlan" ]; then
        BIGIP_IMAGES="$BIGIP_IMAGES BIGIP-11.6.0.0.0.401-OpenStack.qcow2"
        BIGIP_IMAGES="$BIGIP_IMAGES BIGIP-11.5.1.0.0.110-HF-3.0.131-OpenStack.qcow2"
        BIGIP_IMAGES="$BIGIP_IMAGES BIGIP-11.5.1.0.0.110-OpenStack.qcow2"
        BIGIP_IMAGES="$BIGIP_IMAGES BIGIP-11.5.0.0.0.221-HF-0.49.221-OpenStack.qcow2"
        BIGIP_IMAGES="$BIGIP_IMAGES BIGIP-11.5.0.0.0.221-OpenStack.qcow2"
    elif [ $NETWORK_TYPE = "gre" ]; then
        BIGIP_IMAGES="$BIGIP_IMAGES BIGIP-11.6.0.0.0.401-OpenStack.qcow2"
        BIGIP_IMAGES="$BIGIP_IMAGES BIGIP-11.5.1.0.0.110-HF-3.0.131-OpenStack.qcow2"
        BIGIP_IMAGES="$BIGIP_IMAGES BIGIP-11.5.0.0.0.221-HF-0.49.221-OpenStack.qcow2"
    elif [ $NETWORK_TYPE = "vxlan" ]; then
        BIGIP_IMAGES="$BIGIP_IMAGES BIGIP-11.5.1.0.0.110-HF-3.0.131-OpenStack.qcow2"
    fi

    for BIGIP_IMAGE in $BIGIP_IMAGES
    do
        # if user specified --bigip-image then skip others
        if [ -n "$ARG_BIGIP_IMAGE" -a \
                "$BIGIP_IMAGE" != "$ARG_BIGIP_IMAGE" ]; then
            continue
        fi
        f5-onboard-set-state deployments odk-maas BIGIP_IMAGE=$BIGIP_IMAGE
        deploy_test_all_for_bigip_image
    done
}

function deploy_test_all_for_bigip_image {
    set_variation
    show_variation
    # TODO: I believe the reason we are destroying openstack for
    # each big-ip image was that there were disk space issues with
    # trying to loop through all the images in the same openstack
    # instance. This should be fixed because there may be workarounds
    # available now for the disk space issues.
    if [ -z "$NO_DEPLOY" ]; then
        deploy_openstack
    fi
    check_openstack
    deploy_admin_base
    deploy_service_manager

    if [ "$LBAAS_DRIVER" = "none" ]; then
        if [ -n "$ARG_TEST" ]; then
            test_openstack
        fi
        continue
    fi

    for HA_TYPE in pair scalen standalone
    do
      if [ -n "$ARG_HA_TYPE" -a \
              "$HA_TYPE" != "$ARG_HA_TYPE" ]; then
          continue
      fi
      set -x
      f5-onboard-ve-odk deploy-admin-bigips-base \
          --ha-type $HA_TYPE \
          --bigip-image $BIGIP_IMAGE \
          | tee -a $DETAIL_LOG
      testresult=${PIPESTATUS[0]}
      set +x
      if [ $testresult -ne 0 ]; then
          echo -e "`date` Deploy BIG-IPs Base Failed for $variation" \
                | tee -a $SUMMARY_LOG
          exit $testresult
      fi
      SYNC_MODES="replication autosync"
      if [ "$HA_TYPE" = "standalone" \
           -o "$BIGIP_IMAGE" = "BIGIP-11.4.1.608.0-OpenStack.qcow2" ]; then
          SYNC_MODES=replication
      fi
      # Prior to 11.6, tunnels automatically sync (in autosync mode) which
      # causes the plug-in to fail when creating them individually.
      # So don't do autosync, only use replication mode.
      if [ "$BIGIP_IMAGE" = "BIGIP-11.5.0.0.0.221-HF-0.49.221-OpenStack.qcow2"  \
        -o "$BIGIP_IMAGES" = "BIGIP-11.5.1.0.0.110-HF-3.0.131-OpenStack.qcow2" ]; then
          if [ "$NETWORK_TYPE" != "vlan" ]; then
              SYNC_MODES=replication
          fi
      fi
      # todo: test different sync modes without redeploying bigips
      for SYNC_MODE in $SYNC_MODES
      do
        # if user specified --sync-mode then skip others
        if [ -n "$ARG_SYNC_MODE" -a \
                "$SYNC_MODE" != "$ARG_SYNC_MODE" ]; then
          continue
        fi
        set_variation
        variation="$variation\\nbigip $BIGIP_IMAGE"
        variation="$variation\\nha type $HA_TYPE"
        variation="$variation\\nsync mode $SYNC_MODE"
        variation="$variation\\n$NUM_MACHINES node(s)."
        echo 
        echo START OF BIG-IP VARIATION
        echo 
        echo "`date` INFO: odk-openstack deploy: "
        echo -e "$variation started"
        echo 
        echo 

        ATTEMPT=0
        while true
        do
            ATTEMPT=$((ATTEMPT+1))
            set -x
            f5-onboard-ve-odk deploy-admin-bigips \
                --ha-type $HA_TYPE \
                --bigip-image $BIGIP_IMAGE \
                --sync-mode $SYNC_MODE \
                --icontrol-config-mode $ICONTROL_CONFIG_MODE \
                | tee -a $DETAIL_LOG
            testresult=${PIPESTATUS[0]}
            set +x
            if [ $testresult = 0 ]; then
                break
            else
                echo -e "`date` Deploy BIG-IPs Failed, Attempt $ATTEMPT for $variation" \
                      | tee -a $SUMMARY_LOG
                if [ $ATTEMPT = 5 ]; then
                    exit 1
                fi
                
                set -x
                f5-onboard-ve-odk destroy-admin-bigips \
                    --network-type $NETWORK_TYPE \
                    --ha-type $HA_TYPE \
                    --bigip-image $BIGIP_IMAGE \
                    | tee -a $DETAIL_LOG
                set +x
            fi
        done

        if [ -n "$ARG_TEST" ]; then
            echo -e "`date` INFO: odk-openstack deploy: Testing $variation"
            test_openstack
            echo -e "`date` TEST PASSED"
        fi

        # If --all not specifed then exit after one variation
        if [ -z "$ARG_ALL" ]; then
            exit 0
        fi

        echo "`date` Sleeping 60 seconds after test, before destroying big-ips."
        echo "`date` TO ABORT FOR MANUAL TROUBLESHOOTING USE CTRL C NOW"
        sleep 60

        set -x
        f5-onboard-ve-odk destroy-admin-bigips \
            --network-type $NETWORK_TYPE \
            --ha-type $HA_TYPE \
            --bigip-image $BIGIP_IMAGE \
            | tee -a $DETAIL_LOG
        testresult=${PIPESTATUS[0]}
        set +x
        if [ $testresult -ne 0 ]; then
            echo -e "`date` Destroy BIG-IPs Failed for $variation" \
                  | tee -a $SUMMARY_LOG
            exit $testresult
        fi

        echo -e "`date` $variation finished."

        echo "`date` Sleeping 60 seconds before next bigip variation."
        echo "`date` TO ABORT FOR MANUAL TROUBLESHOOTING USE CTRL C NOW"
        sleep 60
      done
      f5-onboard-ve-odk destroy-admin-bigips-base \
          --network-type $NETWORK_TYPE \
          --ha-type $HA_TYPE \
          --bigip-image $BIGIP_IMAGE \
          | tee -a $DETAIL_LOG
      testresult=${PIPESTATUS[0]}
      if [ $testresult -ne 0 ]; then
          echo "`date` Destroy BIG-IPs Base Failed" \
                | tee -a $SUMMARY_LOG
          exit $testresult
      fi
    done
}

