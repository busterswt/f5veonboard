source odk-utils

echo "`date` Start post-test extension."

echo "`date` Copy BIG-IP LBaaS agent log file to /var/tmp..."
rm -f /var/tmp/f5-oslbaasv1-agent.log
if [ "$ODK_DEPLOYER" = "juju" ]; then
    juju scp neutron-gateway/0:/var/log/neutron/f5-oslbaasv1-agent.log /var/tmp
elif [ "$ODK_DEPLOYER" = "packstack" ]; then
    NETWORK_HOST=`odk-get-conf deployments odk-maas NETWORK_HOST`
    scp $NETWORK_HOST:/var/log/neutron/f5-oslbaasv1-agent.log /var/tmp
else
    cp /opt/neutron/var/log/f5-oslbaasv1-agent.log /var/tmp
    echo "`date` Failed. Error copying BIG-IP LBaaS agent log file to /var/tmp. Unknown ODK_DEPLOYER"
    return 1
fi
scp_result=$?
if [ $scp_result != 0 ]; then
    echo "`date` Failed. Error copying BIG-IP LBaaS agent log file to /var/tmp."
    return 1
fi

echo "`date` Search the BIG-IP LBaaS agent log file for errors..."
cat /var/tmp/f5-oslbaasv1-agent.log | grep -v "Failed to consume message" | grep -e ERROR
pipe_status=("${PIPESTATUS[@]}")
cat_result=${pipe_status[0]}
if [ "$cat_result" != "0" ]; then
    echo "`date` Unable to list log file."
    return 1
fi
grep_result=${pipe_status[2]}
if [ "$grep_result" == "0" ]; then
    echo "`date` Errors found in BIG-IP LBaaS agent log file."
    return 1
else
    echo "`date` No errors found in BIG-IP LBaaS agent log file."
fi

echo "`date` Post-test extension completed."
