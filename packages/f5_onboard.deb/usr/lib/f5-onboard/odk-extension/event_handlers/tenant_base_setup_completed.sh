source f5-onboard-utils


SERVICE_MANAGER=`f5-onboard-get-state deployments odk-maas SERVICE_MANAGER`
BIGIP_IMAGE=`f5-onboard-get-state deployments odk-maas BIGIP_IMAGE`

if [ "$SERVICE_MANAGER" = "bigiq" -a \
     "$TENANT_INDEX" = "2" ]; then
    set -e
    f5-onboard-ve-odk deploy-tenant-bigips-base \
        --ha-type standalone \
        --odk-tenant-index $TENANT_INDEX
    f5-onboard-ve-odk deploy-tenant-bigips \
        --odk-tenant-index $TENANT_INDEX \
        --ha-type standalone \
        --bigip-image $BIGIP_IMAGE \
        --sync-mode replication
    set -e
    echo "Now install the iApp rpm and press return"
    read line
fi
