source f5-onboard-utils

if [ "$ODK_DEPLOYER" = "devstack" ]; then
    source $F5_ONBOARD_LIBEXEC_DIR/lbaas/devstack-install.sh
fi

