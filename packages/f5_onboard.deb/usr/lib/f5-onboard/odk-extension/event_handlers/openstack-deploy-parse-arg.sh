
function setup_quickstart_bigip {
    ARG_HA_TYPE=standalone
    ARG_SERVICE_MANAGER=none
    ARG_BIGIQ_IMAGE="BIG-IQ-4.5.0.0.0.7028-OpenStack.qcow2"
    ARG_BIGIP_IMAGE="BIGIP-11.6.0.0.0.401-OpenStack.qcow2"
}

case "$1" in
  --bigip-image)     ARG_BIGIP_IMAGE=$2; shift 2; ODK_PARSED_ARG=true;;
  --bigip-type)      ARG_BIGIP_TYPE=$2; shift 2; ODK_PARSED_ARG=true;;
  --ha-type)         ARG_HA_TYPE=$2; shift 2; ODK_PARSED_ARG=true;;
  --sync-mode)       ARG_SYNC_MODE=$2; shift 2; ODK_PARSED_ARG=true;;
  --icontrol-config-mode) ARG_ICONTROL_CONFIG_MODE=$2; shift 2; ODK_PARSED_ARG=true;;
  --service-manager) ARG_SERVICE_MANAGER=$2; shift 2; ODK_PARSED_ARG=true;;
  --bigiq-image)     ARG_BIGIQ_IMAGE=$2; shift 2; ODK_PARSED_ARG=true;;
  --bigiq-ha-type)   ARG_BIGIQ_HA_TYPE=$2; shift 2; ODK_PARSED_ARG=true;;
  --quickstart)      ARG_QUICKSTART=$1; setup_quickstart_bigip;;
esac

function show_usage {
    _show_usage
    echo " F5 BIG-IP/BIG-IQ Options: " 
    echo "  --bigip-image            BIG-IP qcow image file to use"
    echo "  --bigip-type             BIG-IP Type: onboard-ve static static-vcmp"
    echo "  --ha-type                HA Type: pair scalen standalone"
    echo "  --sync-mode              Sync Mode: replication autosync"
    echo "  --icontrol-config-mode   Config mode: iapp or object"
    echo "  --service-manager        Service Manager Type: bigiq none"
    echo "  --bigiq-image            BIG-IQ qcow image file to use"
    echo "  --bigiq-ha-type          BIG-IQ HA Type: pair scalen standalone"
}

