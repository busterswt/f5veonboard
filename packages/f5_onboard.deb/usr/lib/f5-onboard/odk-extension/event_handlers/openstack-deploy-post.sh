source f5-onboard-utils

$F5_ONBOARD_LIBEXEC_DIR/ve/openstack/patch-nova-release.sh
if [ "$ODK_DEPLOYER" = "juju" ]; then
    $F5_ONBOARD_LIBEXEC_DIR/lbaas/juju-install.sh
fi
if [ "$ODK_DEPLOYER" = "packstack" ]; then
    $F5_ONBOARD_LIBEXEC_DIR/lbaas/packstack-install.sh
fi

