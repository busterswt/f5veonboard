source odk-utils

echo "`date` Start pre-test extension."

echo "`date` Delete BIG-IP LBaaS agent log file on neutron-gateway."
odk_ng rm /var/log/neutron/f5-oslbaasv1-agent.log
rm_result=$?
if [ "$rm_result" != "0" ]; then
    return 1
fi

echo "`date` Restart BIG-IP LBaaS agent."
odk_ng service f5-oslbaasv1-agent restart
service_result=$?
if [ "$service_result" != "0" ]; then
    return 1
fi
echo "`date` BIG-IP LBaaS agent restarted."

echo "`date` Pre-test extension completed."
