source f5-onboard-utils


SERVICE_MANAGER=`f5-onboard-get-state deployments odk-maas SERVICE_MANAGER`
BIGIP_IMAGE=`f5-onboard-get-state deployments odk-maas BIGIP_IMAGE`

if [ "$SERVICE_MANAGER" = "bigiq" -a \
     "$TENANT_INDEX" = "2" ]; then
    set -e
    f5-onboard-ve-odk destroy-tenant-bigips \
        --odk-tenant-index $TENANT_INDEX
    f5-onboard-ve-odk destroy-tenant-bigips-base \
        --odk-tenant-index $TENANT_INDEX \
        --ha-type standalone
    set -e
fi
