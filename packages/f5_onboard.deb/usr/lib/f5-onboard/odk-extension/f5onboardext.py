"""F5 Onboard Extension"""
import os
import sys
from json import dumps
from json import loads
from requests import session
from time import sleep, time
from odk.lib.client import get_neutron_client
from odk.lib.openstack import OpenStackLib
from odk.lib.neutron import NeutronFloatingIpLib
from odk.lib.lbaas import NeutronLBaaSPoolLib
from odk.lib.lbaas import NeutronLBaaSVipLib
from odk.lib.connect import test_lb_vip_members
from odk.extensions import get_cmd_output
from odk.lib.common import get_global
from odk.lib.common import GLOBAL_CHECK

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../../..'))
ODK_DIR = get_cmd_output(['bash', '-c', 'source odk-utils;echo $ODK_DIR'])[0]
sys.path.insert(0, ODK_DIR+'/python')

ICR_USERNAME = 'admin'
ICR_PASSWORD = 'admin'


class ODKExtension(OpenStackLib):
    """F5 ODK Extension"""
    # external network name identifies the specific bigip cluster.
    # This must be set if you want to do object checks.
    def __init__(self, creds, ext_network_name=None):
        OpenStackLib.__init__(self, creds)
        self.bigips = []
        if ext_network_name:
            self.bigips = get_bigips(self.print_context)

        self.f5_obj_check = F5ObjCheck(creds, self.bigips)
        self.f5_test_vip = \
            F5TestVip(creds, self.print_context, self.bigips)

    def run_neutron_diagnostics(self):
        """Run extension diagnostics"""
        agent_lib = F5NeutronAgentLib(self.creds)
        return agent_lib.check_agents()

    def object_check(self, label, expected_result, object_type, *args):
        """Run extension object check"""
        self.f5_obj_check.check(label, expected_result, object_type, *args)

    def test_lb_vip(self, floating_ip_addr, server_text_list):
        """Determine vip location and failover to another BIG-IP"""
        return self.f5_test_vip.test_lb_vip(floating_ip_addr, server_text_list)


def get_cluster_name():
    """Get cluster name"""
    return get_cmd_output(['f5-onboard-get-state', 'deployments', 'odk-maas',
                           'CLUSTER_NAME'])[0]


def get_ha_type():
    """Get BIG-IP HA type"""
    ha_type = None
    cluster = get_cluster_name()
    if cluster:
        ha_type = get_cmd_output(['f5-onboard-get-state', 'clusters', cluster,
                                  'HA_TYPE'])[0]
    return ha_type


def is_ha():
    """Determine if BIG-IP(s) are HA"""
    ha_type = get_ha_type()
    return (ha_type is not None) and (ha_type != 'standalone')


def get_bigips(print_context):
    """Determine BIG-IP(s) in use and initialize iControl REST"""
    bigips = []

    cluster = get_cluster_name()
    if cluster:
        mgmt_ips = get_cmd_output(['f5-onboard-get-state', 'clusters', cluster,
                                  'MGMT_IPS'])
        if mgmt_ips:
            mgmt_ips = mgmt_ips[0].split(',')

            for mgmt_ip in mgmt_ips:
                bigips.append(BigIpRest(print_context, mgmt_ip))

    return bigips


def get_icontrol_config_mode():
    """Get cluster name"""
    cluster = get_cluster_name()
    if cluster:
        return get_cmd_output(['f5-onboard-get-state', 'clusters', cluster,
                              'ICONTROL_CONFIG_MODE'])[0]


# pylint: disable=too-few-public-methods
class BigIpRest(object):
    """Rest connection to BIG-IP"""
    def __init__(self, print_context, mgmt_ip):
        self.print_context = print_context
        self.mgmt_ip = mgmt_ip

        self.icr_session = session()
        self.icr_session.auth = (ICR_USERNAME, ICR_PASSWORD)
        self.icr_session.verify = False
        self.icr_session.headers.update({'Content-Type': 'application/json'})
        self.icr_url = 'https://%s/mgmt/tm' % mgmt_ip

        self.hostname = get_bigip_hostname(self)
# pylint: enable=too-few-public-methods


# pylint: disable=too-few-public-methods
class F5TestVip(object):
    """Test vip"""
    def __init__(self, creds, print_context, bigips):
        self.print_context = print_context
        self.bigips = bigips
        self.neutron_floating_ip = NeutronFloatingIpLib(creds)
        self.neutron_lbaas_vip = NeutronLBaaSVipLib(creds)
        self.neutron_lbaas_pool = NeutronLBaaSPoolLib(creds)
        self.retry_limit_secs = 600
        self.retry_sleep_secs = 0.1

    def __get_openstack_vip(self, floating_ip_addr):
        """Get OpenStack vip associated with a floating ip address"""
        floating_ip = \
            self.neutron_floating_ip.get_floating_ip(floating_ip_addr)
        port_id = floating_ip['port_id']
        vips = self.neutron_lbaas_vip.get_all_lb_vips()
        for vip in vips:
            if vip['port_id'] == port_id:
                return vip
        return None

    def __get_traffic_group_name(self, bigip_vip):
        """Get the traffic group name associated with a vip"""
        bigip_tenant = \
            bigip_vip['destination'].rsplit(':', 1)[0].split('/')[1]
        bigip_virtual_address = \
            bigip_vip['destination'].rsplit(':', 1)[0].split('/')[2].\
            replace('%', '%25')
        bigip_virtual = get_bigip_virtual_address(
            self.bigips[0], bigip_tenant, bigip_virtual_address)
        return bigip_virtual['trafficGroup']

    def __failover_traffic_group(self, bigip, traffic_group_name):
        """Failover traffic group"""
        self.print_context.heading(
            'Issue failover request for %s.' % traffic_group_name)

        request_url = bigip.icr_url + '/sys/failover/'
        payload = {}
        payload['command'] = 'run'
        payload['standby'] = None
        payload['trafficGroup'] = traffic_group_name.split('/')[2]
        response = bigip.icr_session.post(request_url, data=dumps(payload))
        if response.status_code >= 400:
            raise Exception('Bad status code %d for failover request' %
                            response.status_code)

    def test_lb_vip(self, floating_ip_addr, server_text_list):
        """Test vip, failover vip, test vip"""
        result = test_lb_vip_members(floating_ip_addr, server_text_list)
        if not result or not is_ha():
            return result

        # Determine virtual address on BIG-IP
        vip = self.__get_openstack_vip(floating_ip_addr)
        bigip_vip = get_bigip_vip(self.bigips[0], self.neutron_lbaas_pool, vip)
        if not bigip_vip:
            raise Exception('BIG-IP VIP Not Found.')
        self.print_context.heading(
            'BIG-IP HA is configured. Test HA.')

        traffic_group_name = self.__get_traffic_group_name(bigip_vip)
        traffic_group_hostname = \
            get_traffic_group_hostname(self.bigips[0], traffic_group_name)

        if not traffic_group_hostname:
            raise Exception('Host where traffic group %s is active '
                            'was not found.' % traffic_group_name)

        self.print_context.heading('Virtual Server is a member of traffic '
                                   'group %s.' % traffic_group_name)
        self.print_context.heading('Traffic group %s is active on %s.' %
                                   (traffic_group_name,
                                    traffic_group_hostname))

        # Find BIG-IP where traffic group is active and issue failover request
        for bigip in self.bigips:
            if traffic_group_hostname == bigip.hostname:
                self.__failover_traffic_group(bigip, traffic_group_name)

        # Wait until all BIG-IPs agree that the traffic group has failed over
        for _ in range(1, 60):
            failed_over = True
            for bigip in self.bigips:
                new_traffic_group_hostname = \
                    get_traffic_group_hostname(bigip, traffic_group_name)
                if new_traffic_group_hostname and \
                   new_traffic_group_hostname != traffic_group_hostname:
                    self.print_context.heading(
                        'BIG-IP %s shows traffic group'
                        ' failover from %s to %s complete. ' %
                        (bigip.hostname, traffic_group_hostname,
                         new_traffic_group_hostname))
                else:
                    failed_over = False
                    self.print_context.heading(
                        'Traffic group failover not complete on BIG-IP %s. '
                        'Wait for traffic group to failover.' % bigip.hostname)
                    sleep(1)
                    break

            if failed_over:
                self.print_context.heading('Traffic group failover complete.')
                # This sleep is done as a precaution.  Vips have been
                # wedged if they are hit too quickly after being
                # created.  I've seen 'connection reset' errors after failover
                # which are similar to the errors on create, but I have not
                # seen a post-failover vip wedged if hit right after failover.
                # That said, initially, we're going to sleep 30 seconds to
                # see if there are any other issues with failover. If that
                # appears stable, we'll look into timing related to
                # post-failover connectivity testing.
                # update: 30 seconds was stable, moving to 5.
                self.print_context.heading(
                    'Sleeping 5 seconds prior to retesting vip.')
                sleep(5)
                self.print_context.heading('Retest vip.')
                return test_lb_vip_members(floating_ip_addr, server_text_list)

        return False
# pylint: enable=too-few-public-methods


def get_traffic_group_hostname(bigip, traffic_group):
    """Get the hostname of the BIG-IP where the traffic group is active"""
    request_url = bigip.icr_url + '/cm/traffic-group/stats'

    response = bigip.icr_session.get(request_url)
    if response.status_code >= 400:
        return None

    tg_stats = loads(response.text)
    for stat in tg_stats['entries']:
        if (tg_stats['entries'][stat]['nestedStats']['entries']
                    ['trafficGroup']['description'] == traffic_group) and \
           (tg_stats['entries'][stat]['nestedStats']['entries']
                    ['failoverState']['description'] == 'active'):
            return tg_stats['entries'][stat]['nestedStats'][
                'entries']['deviceName']['description'].split('/')[2]

    return None


def check_bigip_folder(bigip, tenant_id):
    """Check for folder on BIG-IP"""
    uuid_folder_name = 'uuid_' + tenant_id

    request_url = bigip.icr_url + '/auth/partition'

    response = bigip.icr_session.get(request_url)
    if response.status_code >= 400:
        return False

    partitions_obj = loads(response.text)
    partitions = partitions_obj['items']
    for partition in partitions:
        if uuid_folder_name in partition['name']:
            return True
    return False


def check_bigip_pool(bigip, pool):
    """Check for pool on BIG-IP"""
    uuid_folder_name = 'uuid_' + pool['tenant_id']
    uuid_pool_name = 'uuid_' + pool['id']
    if get_icontrol_config_mode() == 'iapp':
        uuid_folder_name += '~' + uuid_pool_name + '.app'

    request_url = bigip.icr_url + '/ltm/pool/'
    request_url += '~' + uuid_folder_name + '~' + uuid_pool_name

    response = bigip.icr_session.get(request_url)
    return response.status_code < 400


def check_bigip_pool_member(bigip, pool, member_ip_address):
    """Check for pool on BIG-IP"""
    uuid_folder_name = 'uuid_' + pool['tenant_id']
    uuid_pool_name = 'uuid_' + pool['id']
    if get_icontrol_config_mode() == 'iapp':
        uuid_folder_name += '~' + uuid_pool_name + '.app'

    # iControl REST member-level call (e.g. /members/~folder~address:port)
    # returns configuration data for members that do not exist (BZ 491791).
    # Workaround - Get all members and iterate through them.
    request_url = bigip.icr_url + '/ltm/pool/'
    request_url += '~' + uuid_folder_name + '~' + uuid_pool_name
    request_url += '/members'

    response = bigip.icr_session.get(request_url)
    if response.status_code >= 400:
        return False

    pool_obj = loads(response.text)
    members = pool_obj['items']
    for member in members:
        if member_ip_address in member['address']:
            return True
    return False


def openstack_monitor_type_to_bigip(monitor):
    """Convert OpenStack monitor type to BIG-IP monitor type"""
    monitor_type = monitor['type'].lower()
    if monitor_type == 'ping':
        monitor_type = 'icmp'
    return monitor_type


def check_bigip_monitor(bigip, monitor):
    """Check for monitor on BIG-IP"""
    uuid_folder_name = 'uuid_' + monitor['tenant_id']
    uuid_monitor_name = 'uuid_' + monitor['id']

    monitor_type = openstack_monitor_type_to_bigip(monitor)

    request_url = bigip.icr_url + '/ltm/monitor/' + monitor_type + '/'
    request_url += '~' + uuid_folder_name + '~' + uuid_monitor_name

    response = bigip.icr_session.get(request_url)
    return response.status_code < 400


def check_bigip_monitor_interval(bigip, monitor, monitor_obj):
    """Check OpenStack Delay vs. BIG-IP Interval"""
    msg = '[%s:Monitor Delay] ' % bigip.mgmt_ip
    if not monitor_obj['interval']:
        bigip.print_context.debug('%s BIG-IP value:None', msg)
        return False
    if monitor_obj['interval'] == monitor['delay']:
        msg += 'Pass:'
    else:
        msg += 'Fail:'
    bigip.print_context.debug(
        '%s OpenStack(Delay):%d, BIG-IP(Interval):%d',
        msg, monitor['delay'], monitor_obj['interval'])
    if monitor_obj['interval'] != monitor['delay']:
        return False
    return True


def check_bigip_monitor_timeout(bigip, monitor, monitor_obj):
    """Check OpenStack Timeout * Max Retries vs. BIG-IP Timeout"""
    msg = '[%s:Monitor Timeout] ' % bigip.mgmt_ip
    if not monitor_obj['timeout']:
        bigip.print_context.debug('%s BIG-IP value:None', msg)
        return False
    if monitor_obj['timeout'] == \
       (monitor['timeout'] * monitor['max_retries']):
        msg += 'Pass:'
    else:
        msg += 'Fail:'
    bigip.print_context.debug(
        '%s OpenStack(timeout*max_retries):(%d*%d)%d, BIG-IP(interval):%d',
        msg,
        monitor['timeout'], monitor['max_retries'],
        monitor['timeout'] * monitor['max_retries'],
        monitor_obj['timeout'])
    if monitor_obj['timeout'] != \
       (monitor['timeout'] * monitor['max_retries']):
        return False
    return True


def check_bigip_monitor_props(bigip, monitor):
    """Check monitor properties on BIG-IP"""
    uuid_folder_name = 'uuid_' + monitor['tenant_id']
    uuid_monitor_name = 'uuid_' + monitor['id']

    monitor_type = openstack_monitor_type_to_bigip(monitor)

    request_url = bigip.icr_url + '/ltm/monitor/' + monitor_type + '/'
    request_url += '~' + uuid_folder_name + '~' + uuid_monitor_name

    response = bigip.icr_session.get(request_url)
    if response.status_code >= 400:
        return False
    monitor_obj = loads(response.text)

    if not check_bigip_monitor_interval(bigip, monitor, monitor_obj):
        return False
    if not check_bigip_monitor_timeout(bigip, monitor, monitor_obj):
        return False
    return True


def check_bigip_pool_monitor(bigip, pool, monitor):
    """Check for pool monitor association on BIG-IP"""
    uuid_folder_name = 'uuid_' + pool['tenant_id']
    uuid_pool_name = 'uuid_' + pool['id']
    uuid_monitor_name = 'uuid_' + monitor['id']

    request_url = bigip.icr_url + '/ltm/pool/'
    request_url += '~' + uuid_folder_name + '~' + uuid_pool_name

    response = bigip.icr_session.get(request_url)
    if response.status_code >= 400:
        return False

    uuid_folder_monitor_name = '/' + uuid_folder_name + \
                               '/' + uuid_monitor_name
    pool_obj = loads(response.text)

    # 'monitor' key may not exist in new pool obj
    if 'monitor' not in pool_obj:
        return False
    return uuid_folder_monitor_name in pool_obj['monitor']


def check_bigip_vip(bigip, creds, vip):
    """Check for vip on BIG-IP"""
    uuid_folder_name = 'uuid_' + vip['tenant_id']
    if get_icontrol_config_mode() == 'iapp':
        # iApp folder/name is based on pool id.
        neutron_lbaas_pool = NeutronLBaaSPoolLib(creds)
        pool = neutron_lbaas_pool.get_lb_pool_by_id(vip['pool_id'])
        uuid_folder_name += '~uuid_' + pool['id'] + '.app'
        uuid_vip_name = 'uuid_' + pool['id']
    else:
        uuid_vip_name = 'uuid_' + vip['id']

    request_url = bigip.icr_url + '/ltm/virtual/'
    request_url += '~' + uuid_folder_name + '~' + uuid_vip_name

    response = bigip.icr_session.get(request_url)
    return response.status_code < 400


def get_bigip_vip(bigip, neutron_lbaas_pool, vip):
    """Get BIG-IP vip"""
    uuid_folder_name = 'uuid_' + vip['tenant_id']
    if get_icontrol_config_mode() == 'iapp':
        # iApp folder/name is based on pool id.
        pool = neutron_lbaas_pool.get_lb_pool_by_id(vip['pool_id'])
        uuid_folder_name += '~uuid_' + pool['id'] + '.app'
        uuid_vip_name = 'uuid_' + pool['id']
    else:
        uuid_vip_name = 'uuid_' + vip['id']

    request_url = bigip.icr_url + '/ltm/virtual/'
    request_url += '~' + uuid_folder_name + '~' + uuid_vip_name

    response = bigip.icr_session.get(request_url)
    if response.status_code < 400:
        return loads(response.text)
    return None


def get_bigip_virtual_address(bigip, tenant, virtual_address):
    """Get BIG-IP virtual address"""
    request_url = bigip.icr_url + '/ltm/virtual-address/'
    request_url += '~' + tenant + '~' + virtual_address

    response = bigip.icr_session.get(request_url)
    if response.status_code < 400:
        return loads(response.text)
    return None


def get_bigip_hostname(bigip):
    """Get BIG-IP Hostname"""
    request_url = bigip.icr_url + '/sys/global-settings'

    response = bigip.icr_session.get(request_url)
    if response.status_code < 400:
        global_settings = loads(response.text)
        return global_settings['hostname']
    return None


def format_obj_name(name):
    """Truncate long GUID-style names"""
    if len(name) > 11:
        return name[:4] + '...' + name[-4:]
    else:
        return name


def build_obj_name_from_args(object_type, *args):
    """Build object name from args and defined arg name keys"""
    obj_name = ''
    if object_type not in OBJ_CHECK_DEF:
        return 'object type not defined'
    for arg, keys in zip(args, OBJ_CHECK_DEF[object_type]['arg_name_keys']):
        for key in keys:
            if key is None:
                if object_type == 'tenant':
                    obj_name += 'uuid_'
                elif object_type != 'pool_member':
                    obj_name += '/'
                obj_name += format_obj_name(arg)
            else:
                obj_name += '/uuid_' + format_obj_name(arg[key])

        if arg != args[-1]:
            obj_name += ', '
    return obj_name


# If a BIG-IP check function causes issues with plugin operations, comment out
# the object check definition, and the check function will be skipped.
#
OBJ_CHECK_DEF = {'tenant': {'function': check_bigip_folder,
                            'openstack_creds': False,
                            'arg_name_keys': [[None]],
                            'fail_labels':   ['Tenant found on',
                                              'Tenant not found on']},
                 'pool': {'function': check_bigip_pool,
                          'openstack_creds': False,
                          'arg_name_keys': [['tenant_id', 'id']],
                          'fail_labels':   ['Pool found on',
                                            'Pool not found on']},
                 'pool_member': {'function': check_bigip_pool_member,
                                 'openstack_creds': False,
                                 'arg_name_keys': [['tenant_id', 'id'],
                                                   [None]],
                                 'fail_labels':  ['Pool member found on',
                                                  'Pool member not found on']},
                 'monitor': {'function': check_bigip_monitor,
                             'openstack_creds': False,
                             'arg_name_keys': [['tenant_id', 'id']],
                             'fail_labels':   ['Monitor found on',
                                               'Monitor not found on']},
                 'monitor_props': {'function': check_bigip_monitor_props,
                                   'openstack_creds': False,
                                   'arg_name_keys': [['tenant_id', 'id']],
                                   'fail_labels':  ['Properties match on',
                                                    'Properties mismatch on']},
                 'pool_monitor': {'function': check_bigip_pool_monitor,
                                  'openstack_creds': False,
                                  'arg_name_keys': [['tenant_id', 'id'],
                                                    ['tenant_id', 'id']],
                                  'fail_labels':   ['Associated on',
                                                    'Not associated on']},
                 'vip': {'function': check_bigip_vip,
                         'openstack_creds': True,
                         'arg_name_keys': [['tenant_id', 'id']],
                         'fail_labels':   ['Vip found on',
                                           'Vip not found on']}}


# Check object create/delete
# pylint: disable=too-few-public-methods
class F5ObjCheck(OpenStackLib):
    """Check for object"""
    def __init__(self, creds, bigips):
        OpenStackLib.__init__(self, creds)

        self.retry_limit_secs = 600
        self.retry_sleep_secs = 0.1
        self.output_interval_secs = 10

        self.start_time = None
        self.last_output_time = None

        self.bigips = bigips

    def __reached_timeout(self):
        """Check if run time has exceeded limit"""
        return (time() - self.start_time) > self.retry_limit_secs

    def __raise_bigip_exception(self, label):
        """Raise exception when check fails"""
        msg = 'Check BIG-IP %s failed after %.1f seconds' % \
              (label, (time() - self.start_time))
        raise Exception(msg)

    def __check_all_bigips_for_object(self, object_type, expected_result,
                                      *args):
        """Check for object on all BIG-IPs"""
        bigips_pass = []
        bigips_fail = []
        for bigip in self.bigips:
            if object_type not in OBJ_CHECK_DEF:
                continue
            if OBJ_CHECK_DEF[object_type]['openstack_creds']:
                object_found = \
                    OBJ_CHECK_DEF[object_type]['function'](
                        bigip, self.creds, *args)
            else:
                object_found = \
                    OBJ_CHECK_DEF[object_type]['function'](bigip, *args)
            if (expected_result and object_found) or \
               (not expected_result and not object_found):
                bigips_pass.append(bigip.mgmt_ip)
            else:
                bigips_fail.append(bigip.mgmt_ip)

        return {'obj_type': object_type,
                'obj_name': build_obj_name_from_args(object_type, *args),
                'bigips_pass': bigips_pass,
                'bigips_fail': bigips_fail}

    def __print_bigips_check_results(self, check_output, expected_result,
                                     attempt_number):
        """Print check output"""
        # Don't print anything if there aren't any BIG-IPs or results
        if (len(self.bigips) == 0) or \
            (len(check_output['bigips_pass']) == 0 and
                len(check_output['bigips_fail']) == 0):
            return

        # Only output failed tests at the output interval
        time_since_last_output = time() - self.last_output_time
        test_passed = len(check_output['bigips_fail']) == 0
        if not test_passed and \
           (time_since_last_output < self.output_interval_secs):
            return

        # Format message - Results, remaining objs, time remaining/elapsed
        msg = 'Check BIG-IP %s %s ' % \
            (check_output['obj_type'], check_output['obj_name'])

        msg += check_output['label']

        if test_passed:
            msg += '. Attempt %d passed.' % attempt_number
            msg += ' Check time %.1f seconds.' % (time() - self.start_time)
        else:
            msg += '. Attempt %d failed.' % attempt_number
            self.print_context.debug(msg)
            msg = '>' + OBJ_CHECK_DEF[
                check_output['obj_type']]['fail_labels'][expected_result]
            msg += ' BIG-IP(s):%s.' % check_output['bigips_fail']
            msg += ' Timeout in %.0f seconds.' % \
                (max(self.retry_limit_secs - (time() - self.start_time), 0))

        # Print message
        self.print_context.debug(msg)

        # Adjust output time to account for time over output_interval_secs
        self.last_output_time = time() - \
            (time_since_last_output % self.output_interval_secs)

    def check(self, label, expected_result, object_type, *args):
        """Support for BIG-IP check"""
        if not get_global(GLOBAL_CHECK) or not len(self.bigips):
            return
        if get_icontrol_config_mode() == 'iapp':
            if not object_type in ['tenant', 'pool', 'pool_member', 'vip']:
                self.print_context.debug(
                    'iApp mode.  Skipping BIG-IP %s object check', object_type)
                return

        self.start_time = time()
        self.last_output_time = time() - self.output_interval_secs

        attempt_number = 1
        while not self.__reached_timeout():
            # pylint: disable=bare-except
            try:
                check_output = self.__check_all_bigips_for_object(
                    object_type, expected_result, *args)
                check_output['label'] = label

                self.__print_bigips_check_results(
                    check_output, expected_result, attempt_number)

                if len(check_output['bigips_fail']) == 0:
                    return
            except:
                self.print_context.heading('=================================')
                self.print_context.heading('Eat exception (%s)',
                                           sys.exc_info()[0])
                self.print_context.heading('=================================')
            # pylint: enable=bare-except
            sleep(self.retry_sleep_secs)
            attempt_number += 1
        self.__raise_bigip_exception(label)
# pylint: enable=too-few-public-methods


class F5NeutronAgentLib(OpenStackLib):
    """Neutron Agent Library"""
    def __init__(self, creds):
        OpenStackLib.__init__(self, creds)
        self.neutron_admin = get_neutron_client(creds)

    def check_agents(self):
        """Check F5 Neutron agents."""
        self.print_context.heading('Check F5 Neutron agents.')
        f5_lbaas_agent_configured = len(get_cmd_output(['f5-onboard-lbaas',
                                        'get-bigip-plugin-config'])) != 0
        print "f5 lbaas agent configured: %s" % f5_lbaas_agent_configured

        agent_list = self.neutron_admin.list_agents()['agents']
        f5_lbaas_agent_found = False
        for agent in agent_list:
            if agent['alive'] is True and \
                (agent['binary'] == 'f5-bigip-lbaas-agent' or
                 agent['binary'] == 'f5-oslbaasv1-agent'):
                f5_lbaas_agent_found = True

        if f5_lbaas_agent_found:
            if f5_lbaas_agent_configured:
                self.print_context.heading(
                    '>Passed: F5 Agent is alive.')
                return True
            else:
                self.print_context.heading(
                    '>Failed: Unexpected F5 Agent found. Agents:')
        else:
            if f5_lbaas_agent_configured:
                self.print_context.heading(
                    '>Failed: No F5 Agent is alive. Agents: ')
            else:
                self.print_context.heading(
                    '>Passed: No F5 Agent is alive.')
                return True

        for agent in agent_list:
            self.print_context.heading(
                '>%s %s' % (agent['binary'], agent['alive']))
        return False
